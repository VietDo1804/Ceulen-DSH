import type { PluginContext, TextBlock, ToolContent, ToolDefinition, ToolRunContext } from './types.js';
/** One text-only tool result. */
export declare function text(value: string): readonly TextBlock[];
export declare function jsonText(value: unknown): readonly TextBlock[];
/** Per-tool repair of the literal mistakes models make in the arguments object. */
export interface ToolContract {
    /** Overrides the derived one-line call shape shown on an error. */
    usage?: string;
    /** Extra normalization after schema coercion; must not invent a required value. */
    normalize?(args: Record<string, unknown>): Record<string, unknown>;
}
export interface CeulenToolOptions {
    name: string;
    description: string;
    parameters: Record<string, unknown>;
    /** Argument repair and the call-shape hint shown when the body rejects a call. */
    contract?: ToolContract;
    /** Canonical output schema; defaults to a string. */
    outputSchema?: Record<string, unknown>;
    /** Optional custom content projection (e.g. image + text). */
    render?: (args: unknown, value: unknown) => ToolContent;
    /** Tool-private JSON the UI reads back from the settled result. */
    presentationMeta?: ToolDefinition['output']['presentationMeta'];
    /** Host-plane card intent for the pending call. */
    presentCall?: ToolDefinition['presentCall'];
    /** Host-plane card intent for the settled call. */
    presentResult?: ToolDefinition['presentResult'];
    timeoutMs?: number;
    concurrencySafe?: boolean | ((args: unknown) => boolean);
    execute(args: unknown, exec: ToolRunContext): Promise<unknown>;
}
/**
 * Build a plain `ToolDefinition`. We intentionally avoid `defineTool` so the
 * package carries no runtime import from the harness; the registry accepts the
 * same structural shape.
 */
export declare function ceulenTool(options: CeulenToolOptions): ToolDefinition;
export interface RegisteredTool {
    readonly requested: string;
    readonly actual: string;
    readonly renamed: boolean;
}
/**
 * Prompt-budget ledger: every registered schema is prompt bytes on every turn,
 * and a budget cannot be kept for a surface nobody counted. Process-local, no
 * I/O; `/ceulen tools` reads it (with the live registry as the count source).
 */
export interface ToolBudgetEntry {
    name: string;
    descriptionBytes: number;
    parameterBytes: number;
}
export declare function toolBudgetEntries(): readonly ToolBudgetEntry[];
/** Clear the ledger (`session/created`, tests). */
export declare function resetToolBudget(): void;
export declare function coldToolEntries(): readonly ToolBudgetEntry[];
export declare function coldTool(name: string): ToolDefinition | undefined;
export declare function resetColdTools(): void;
export declare function holdNativeTool(definition: ToolDefinition): void;
export declare function nativeTool(name: string): ToolDefinition | undefined;
export declare function nativeToolEntries(): readonly ToolBudgetEntry[];
export declare function resetNativeTools(): void;
/**
 * Register a tool, avoiding duplicate names. A collision is not fatal: the tool
 * is exposed as `ceulen_<name>` when that alias is free, so the module remains
 * usable alongside a native tool with the same name.
 */
export declare function registerToolSafe(ctx: PluginContext, definition: ToolDefinition): RegisteredTool;
/** Register a command, logging rather than throwing on a duplicate. */
export declare function registerCommandSafe(ctx: PluginContext, registration: Parameters<PluginContext['commands']['register']>[0]): boolean;
/**
 * Publish one keyed TUI status line. The TUI rejects writes made from the
 * plugin's composition root ("requires a live non-root plugin activation"),
 * so the service is resolved through an injected child activation instead;
 * a root-context write silently no-ops (the usage module's finding).
 */
export declare function tuiStatusPublisher(ctx: PluginContext, key: string): (text: string | undefined) => void;
/** Register a system-prompt section, tolerating an absent prompt service. */
export declare function registerPromptSection(ctx: PluginContext, section: Parameters<PluginContext['systemPrompt']['section']>[0]): boolean;
export declare function errorMessage(error: unknown): string;
/** Build an object JSON Schema with no additional properties by default. */
export declare function objectSchema(properties: Record<string, unknown>, required?: string[], additionalProperties?: boolean): Record<string, unknown>;
export declare function asRecord(value: unknown): Record<string, unknown>;
export declare function asString(value: unknown, fallback?: string): string;
export declare function asNumber(value: unknown, fallback: number): number;
export declare function asBoolean(value: unknown, fallback: boolean): boolean;
/** Clamp a command's output so a TUI transcript stays readable. */
export declare function clampText(value: string, max?: number): string;
/** Render a simple aligned key/value block for command output. */
export declare function renderPairs(pairs: readonly [string, string][]): string;
//# sourceMappingURL=tools.d.ts.map