/** Read UTF-8 text, returning `undefined` for any missing/unreadable file. */
export declare function readText(path: string): Promise<string | undefined>;
/** Read and parse JSON, returning `undefined` for missing or malformed files. */
export declare function readJson<T>(path: string): Promise<T | undefined>;
export declare function fileExists(path: string): Promise<boolean>;
export declare function ensureDir(path: string, mode?: number): Promise<void>;
/**
 * Atomic write: create a sibling temp file, fsync by close, rename over the
 * target, then tighten the mode. A failed write never leaves a partial file.
 */
export declare function writeAtomic(path: string, data: string, mode?: number): Promise<void>;
export declare function writeJsonAtomic(path: string, value: unknown, mode?: number): Promise<void>;
export declare function sha256(data: string | Uint8Array): string;
/** Normalize CRLF so vendored-file hashes are platform-independent. */
export declare function normalizeText(text: string): string;
/** Fail after `ms` with a clear error; used around optional network calls. */
export declare function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T>;
//# sourceMappingURL=fsx.d.ts.map