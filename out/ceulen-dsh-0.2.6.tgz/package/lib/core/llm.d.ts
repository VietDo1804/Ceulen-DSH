import { type ReasoningEffort } from './settings.js';
import type { PluginContext } from './types.js';
export interface LlmRoute {
    provider: string;
    model: string;
    reasoningEffort?: string;
    sessionId?: string;
}
export interface ParsedRoute {
    provider: string;
    model: string;
    reasoningEffort?: ReasoningEffort;
}
/**
 * Parse a `provider/model[:effort]` selector.
 *
 * The route is split at the first slash (a model id may carry more); a trailing
 * `:effort` is only honoured when the suffix is a known reasoning level, so ids
 * like `model:free` survive intact.
 */
export declare function parseRoute(value: string): ParsedRoute | undefined;
/** Streamed text plus the reason the stream ended; `max-tokens` means a cut reply. */
export interface StreamedText {
    readonly text: string;
    readonly finish: string;
}
/**
 * Stream one auxiliary model call and keep the finish reason. Reasoning models
 * bill their thinking against `maxTokens`, so an empty `text` is ambiguous:
 * `finish: 'max-tokens'` is a truncated reply, `finish: 'stop'` is a clean
 * no-answer (the advisor's explicit no-note signal).
 */
export declare function streamTextDetailed(ctx: PluginContext, route: LlmRoute, system: string, user: string, signal: AbortSignal, maxTokens?: number): Promise<StreamedText>;
/** Stream one auxiliary model call and return its visible text. */
export declare function streamText(ctx: PluginContext, route: LlmRoute, system: string, user: string, signal: AbortSignal, maxTokens?: number): Promise<string>;
/** Extract the first JSON object/array from a model reply. */
export declare function extractJson(text: string): unknown;
//# sourceMappingURL=llm.d.ts.map