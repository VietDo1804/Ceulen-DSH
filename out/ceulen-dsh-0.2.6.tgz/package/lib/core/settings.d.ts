export type PonytailLevel = 'off' | 'lite' | 'full' | 'ultra';
export type UxMode = 'off' | 'lite' | 'strict';
/** Behaviour-scoped rule guards: off, audit (log), or enforce (deny). */
export type RuleGuardMode = 'off' | 'audit' | 'enforce';
export declare const REASONING_EFFORTS: readonly ["off", "minimal", "low", "medium", "high", "xhigh", "max"];
export type ReasoningEffort = (typeof REASONING_EFFORTS)[number];
export interface CeulenSettings {
    schemaVersion: 1;
    disabled: string[];
    upstream: {
        enabled: boolean;
        intervalHours: number;
    };
    advisor: {
        provider: string | null;
        model: string | null;
        reasoningEffort: ReasoningEffort | null;
        fallbacks: string[];
        watch: boolean;
        showStatus: boolean;
        minToolCalls: number;
    };
    classifier: {
        provider: string | null;
        model: string | null;
        audit: boolean;
        /** Block irreversible bash when the gate score is below 0.5. */
        enforce: boolean;
        /** provider/model routes tried in order when the primary route fails. */
        fallbacks: string[];
    };
    munin: {
        project: string;
        baseUrl: string;
        allowProjectConfig: boolean;
        /**
         * Secondary endpoint, tried when the primary is unreachable (munin cloud ->
         * the opimem bridge on the Pi). Empty baseUrl = failover off. The key never lives in
         * this file: it resolves from MUNIN_FALLBACK_API_KEY (env or DSH store).
         */
        fallback: {
            baseUrl: string;
        };
        /** First-turn memory brief: evidence, not instructions (default off). */
        brief: {
            enabled: boolean;
            maxChars: number;
            recencyDays: number;
        };
    };
    /**
     * Second memory family: one opimem server (same wire protocol as Munin) on
     * its own project and key, so `munin_*` and `agentmem_*` can point at two
     * servers at once. No fallback and no project config by design — this store
     * sits on the LAN and answers ~50x faster than the cloud; since 2026-11-02
     * it holds the Pi replica that `munin.fallback` fails over to.
     */
    agentmem: {
        project: string;
        baseUrl: string;
        /** First-turn memory brief: evidence, not instructions (default off). */
        brief: {
            enabled: boolean;
            maxChars: number;
            recencyDays: number;
        };
    };
    cron: {
        enabled: boolean;
        tickMs: number;
    };
    /** Prompt-budget knobs for the tool surface. */
    tools: {
        /** Tool names held out of the prompt and reachable through `ceulen_tools`. */
        cold: string[];
    };
    rules: {
        projectFile: string;
        userFile: string;
        maxBytes: number;
        /** `when-*` guards: `audit` logs matches, `enforce` denies `when-action: deny`. */
        guards: RuleGuardMode;
    };
    ponytail: {
        level: PonytailLevel;
    };
    ux: {
        mode: UxMode;
    };
    web: Record<string, unknown>;
    a2a: {
        peers: unknown[];
    };
    gh: {
        enabled: boolean;
    };
    codemode: {
        enabled: boolean;
        /** Hint after N consecutive single read-only steps; 0 disables. */
        chainHintAfter: number;
    };
    rtk: {
        enabled: boolean;
    };
    subagent: {
        /** Function alias (`fast`, `coder`, `smart`) -> ordered `provider/model[:effort]` chain. */
        roles: Record<string, string[]>;
        /** Per-role selector override; beats the role's own function alias. */
        models: Record<string, string>;
        /** Per-role reasoning-effort override; a matched chain suffix still wins. */
        thinking: Record<string, ReasoningEffort>;
        /** Per-role DSH agent preset; omission inherits the parent's composition. */
        presets: Record<string, string>;
    };
    /** Per-phase routes over the native plan mode: plan on one model, execute on another. */
    plan: {
        /** Route used while plan mode is active; empty inherits the client route. */
        model: string;
        /** Route used once a plan was submitted; empty inherits the client route. */
        implement: string;
    };
    usage: {
        enabled: boolean;
        showStatus: boolean;
        intervalMinutes: number;
        providers: string[];
    };
    [key: string]: unknown;
}
export declare function defaultSettings(): CeulenSettings;
/** `provider/model[:effort]` without the effort suffix. */
export declare function routeBase(route: string): string;
/**
 * One fallback entry per model: a list that names the same provider/model with
 * and without an `:effort` suffix (stale panel writes, hand-edited files) keeps
 * only its first entry.
 */
export declare function dedupeRoutes(routes: readonly string[]): string[];
/**
 * Merge a raw settings document over the defaults, coercing every known field
 * and preserving unknown top-level/section keys for forward compatibility.
 */
export declare function normalizeSettings(raw: unknown): CeulenSettings;
/** Read the settings document synchronously; malformed/missing → defaults. */
export declare function loadSettingsSync(): CeulenSettings;
export declare function saveSettings(settings: CeulenSettings): Promise<void>;
export declare function updateSettings(mutator: (settings: CeulenSettings) => void): Promise<CeulenSettings>;
export declare function isModuleEnabled(name: string, settings?: CeulenSettings): boolean;
export declare function setModuleEnabled(name: string, enabled: boolean): Promise<CeulenSettings>;
/** Reject obvious secret-bearing keys in settings; secrets belong in env. */
export declare function looksSecretKey(key: string): boolean;
/** Copy with secret-looking values masked; used by `/ceulen config`. */
export declare function redactSettings(value: unknown): unknown;
//# sourceMappingURL=settings.d.ts.map