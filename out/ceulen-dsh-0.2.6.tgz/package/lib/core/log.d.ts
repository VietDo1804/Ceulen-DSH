/** Remove token-shaped strings and any live secret env values from a line. */
export declare function redact(text: string): string;
/**
 * Append one line to a Ceulen log. Logging must never break a turn: every
 * failure is swallowed. Callers pass a message, never a credential.
 */
export declare function appendLog(name: string, message: string): Promise<void>;
/** Fire-and-forget variant for hot paths. */
export declare function logLine(name: string, message: string): void;
/**
 * Resolve once every fire-and-forget log write has landed. Tests call this
 * before deleting a temp `DSH_HOME`, so a late write cannot recreate the
 * directory mid-removal (`ENOTEMPTY`).
 */
export declare function flushLogs(): Promise<void>;
export declare function logJson(name: string, value: unknown): void;
//# sourceMappingURL=log.d.ts.map