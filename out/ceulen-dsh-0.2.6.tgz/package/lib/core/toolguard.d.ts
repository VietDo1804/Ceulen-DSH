/**
 * Call-shape helpers for the contract layer: derive the accepted call shape
 * from a JSON object schema and repair the literal mistakes models make.
 *
 * Pure functions, no harness import, no module knowledge. `tools.ts` imports
 * this file and not the other way round, so there is no cycle.
 */
/**
 * Call shape derived from a JSON object schema: `read_slice({ path, start? })`,
 * required keys first, optional keys marked `?`. Written as a call so a
 * one-key shape (`apply_patch({ patch })`) cannot be read as a tool name.
 */
export declare function synthesizeUsage(schema: Record<string, unknown>, name?: string): string;
/** Append `Call as: <shape>` to a message; no-op when the marker is already there. */
export declare function withCallShape(message: string, shape: Record<string, unknown> | string, name?: string): string;
/** The required keys an arguments object does not carry. */
export declare function missingRequired(args: unknown, schema: Record<string, unknown>): string[];
/**
 * What is wrong with the arguments object against the top level of its schema,
 * or undefined when it fits. This decides whether a failure is about the call
 * shape: a body that rejects well-shaped arguments (a hunk that does not match,
 * a refused path) gains nothing from being told the shape again.
 */
export declare function shapeProblem(args: unknown, schema: Record<string, unknown>): string | undefined;
/** Coerce literal strings and single values; never invents a missing required key. */
export declare function coerceBySchema(raw: unknown, schema: Record<string, unknown>): Record<string, unknown>;
//# sourceMappingURL=toolguard.d.ts.map