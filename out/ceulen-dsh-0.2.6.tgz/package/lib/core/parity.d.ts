export type ParityStatus = 'port' | 'config' | 'partial' | 'native' | 'na' | 'deferred';
export interface ParityModule {
    name: string;
    category: string;
    status: ParityStatus;
    dsh: string;
    phase: number;
    notes?: string;
    /** Bundle row id when this module is mounted; absent for native/na/deferred. */
    rowId?: string;
}
export interface ParityDoc {
    schemaVersion: 1;
    upstream: {
        package: string;
        repo: string;
        version: string;
        commit?: string;
    };
    modules: ParityModule[];
}
export declare function statusLabel(status: ParityStatus): string;
export declare function loadParity(): ParityDoc;
export declare function isImplemented(module: ParityModule): boolean;
export declare function summary(doc: ParityDoc): {
    total: number;
    implemented: number;
    ported: number;
    native: number;
    other: number;
};
/** Grouped status text for `/ceulen`; deliberately compact for a TUI transcript. */
export declare function formatParity(doc: ParityDoc, disabled: readonly string[], maxChars?: number): string;
//# sourceMappingURL=parity.d.ts.map