export interface UpstreamRelease {
    version: string;
    tag?: string;
    name?: string;
    url?: string;
    body?: string;
    publishedAt?: string;
}
export interface UpstreamState {
    schemaVersion: 1;
    checkedAt: string;
    source: 'npm' | 'github' | 'cache' | 'fixture' | 'pinned';
    latest: string | null;
    pinned: string;
    behind: boolean;
    release?: UpstreamRelease;
    error?: string;
}
export interface UpstreamDeps {
    fetcher?: typeof fetch;
    now?: () => number;
    timeoutMs?: number;
}
/** Pinned upstream version: env override, lock file, then the bundle base. */
export declare function readPinnedVersion(): string;
export declare function readUpstreamCache(): Promise<UpstreamState | undefined>;
export declare function isCacheFresh(state: {
    checkedAt: string;
}, intervalHours: number, now?: number): boolean;
/**
 * Resolve the latest Ceulen release. Network failures never throw: the result
 * carries the cached state (if any) plus an error string.
 */
export declare function checkUpstream(options?: {
    force?: boolean;
    offline?: boolean;
    intervalHours?: number;
}, deps?: UpstreamDeps): Promise<UpstreamState>;
/** Cheap status read: cache only, falling back to the pinned version. */
export declare function currentUpstreamState(): Promise<UpstreamState>;
export declare function formatAge(iso: string, now?: number): string;
export declare function formatUpstream(state: UpstreamState): string;
/** Status-line text; `undefined` clears the contribution. */
export declare function statusLine(state: UpstreamState, bundleVersion: string): string | undefined;
/**
 * This bundle's own release channel: the `ceulen-dsh` package on npm. Installed
 * copies update with `dsh plugin add`, so the same registry answers both "is a
 * newer bundle out" and "what should the upgrade command pin".
 */
export interface BundleUpdateState {
    schemaVersion: 1;
    checkedAt: string;
    latest: string | null;
    installed: string;
    behind: boolean;
    error?: string;
}
export declare function readBundleCache(): Promise<BundleUpdateState | undefined>;
export declare function checkBundleUpdate(options?: {
    force?: boolean;
    offline?: boolean;
    intervalHours?: number;
}, deps?: UpstreamDeps): Promise<BundleUpdateState>;
/** Cheap status read: cache only, falling back to the installed version. */
export declare function currentBundleUpdate(): Promise<BundleUpdateState>;
export declare function formatBundleUpdate(state: BundleUpdateState): string;
/** Status-line text for a newer bundle; `undefined` when current or unknown. */
export declare function bundleStatusLine(state: BundleUpdateState): string | undefined;
//# sourceMappingURL=upstream.d.ts.map