export interface Semver {
    major: number;
    minor: number;
    patch: number;
    prerelease: string[];
}
export declare function parseSemver(input: string): Semver | undefined;
/** Standard semver precedence; returns -1, 0 or 1; invalid input throws. */
export declare function compareSemver(a: string, b: string): number;
export declare function isNewer(candidate: string, baseline: string): boolean;
export interface PackageManifest {
    name?: string;
    version?: string;
    /** A manifest with a release line carries its own semver (`0.1.1`). */
    release?: {
        line?: string;
        distTag?: string;
    };
}
export declare function readManifest(): PackageManifest;
export declare function pluginVersion(manifest?: PackageManifest): string;
/** Release line declared by the manifest (`stable`); absent on legacy manifests. */
export declare function releaseLine(manifest?: PackageManifest): string | undefined;
/** npm dist-tag the bundle check follows: `release.distTag`, else the line. */
export declare function releaseDistTag(manifest?: PackageManifest): string | undefined;
/**
 * Upstream base of the bundle version, e.g. `0.23.0` from `0.23.0-dsh.1`.
 * A manifest with a `release.line` carries its own line version (`0.1.1`), so
 * its upstream base comes from `upstream.lock.json` instead of the dash split;
 * a legacy version-only manifest keeps the dash behaviour.
 */
export declare function upstreamBaseVersion(manifest?: PackageManifest, locked?: string | undefined): string;
//# sourceMappingURL=version.d.ts.map