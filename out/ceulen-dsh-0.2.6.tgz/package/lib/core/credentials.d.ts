export interface CredentialResolution {
    value?: string;
    source?: 'env' | 'dsh-credential';
    ref?: string;
}
/** Resolve the first present reference: environment wins, then the DSH store. */
export declare function credential(...refs: string[]): CredentialResolution;
/** Whether a reference resolves, without exposing the value. */
export declare function hasCredential(...refs: string[]): boolean;
/** Reset the credential cache (tests). */
export declare function resetCredentialCache(): void;
//# sourceMappingURL=credentials.d.ts.map