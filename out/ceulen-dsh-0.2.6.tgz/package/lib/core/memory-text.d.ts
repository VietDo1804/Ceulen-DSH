/**
 * Clip memory-search output past the first `keepFull` hits to `maxBody` chars
 * of Content, keeping every header line (Key, Title, Score, …) and any trailing
 * `Total: N` footer. Text without hit markers passes through unchanged.
 */
export declare function clipSearchHits(text: string, keepFull?: number, maxBody?: number): string;
//# sourceMappingURL=memory-text.d.ts.map