/** Resolve `$DSH_HOME`, falling back to `~/.dsh` (same precedence as DSH). */
export declare function dshHome(): string;
/** Ceulen-owned state under the harness home. */
export declare function ceulenHome(): string;
/** Cache directory for upstream metadata and tarballs. */
export declare function ceulenCache(): string;
export declare function settingsPath(): string;
export declare function logsDir(): string;
export declare function upstreamCachePath(): string;
/** Cache for this bundle's own npm version check. */
export declare function bundleCachePath(): string;
/** Absolute package root (the directory holding package.json). */
export declare function packageRoot(): string;
export declare function packageFile(...segments: string[]): string;
/** Resolve a path against the session cwd, leaving absolute paths alone. */
export declare function resolveProjectPath(cwd: string, path: string): string;
export declare function displayPath(path: string): string;
//# sourceMappingURL=paths.d.ts.map