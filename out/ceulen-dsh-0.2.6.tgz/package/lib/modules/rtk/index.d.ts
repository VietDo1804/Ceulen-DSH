import type { PluginContext } from '../../core/types.js';
export declare const name = "ceulen-rtk";
export declare const inject: string[];
interface RtkStatus {
    available: boolean;
    version: string | null;
    reason?: string;
}
/** Reject rewrites that change the first word or add shell operators. */
export declare function isSafeRewrite(original: string, rewritten: string): boolean;
export interface RewriteOutcome {
    status: RtkStatus;
    original: string;
    rewritten: string | null;
    reason?: string;
}
/**
 * `--` keeps a command whose first word starts with `-` from parsing as an
 * `rtk rewrite` switch (`rtk rewrite -- ls` behaves like `rtk rewrite ls`).
 */
export declare function rewriteArgs(command: string): readonly string[];
export declare function rewriteCommand(command: string): Promise<RewriteOutcome>;
export declare function apply(ctx: PluginContext): void;
export {};
//# sourceMappingURL=index.d.ts.map