import type { MessageLike, PluginContext } from '../../core/types.js';
export declare const name = "ceulen-todoview";
export declare const inject: string[];
export interface TodoItem {
    content: string;
    status: 'pending' | 'in_progress' | 'completed';
}
/**
 * The newest `todo_write` call carries the whole board, so replaying the
 * session transcript and letting the last call win is the current state.
 * Returns undefined when the session never wrote a todo list.
 */
export declare function latestTodos(messages: readonly MessageLike[]): TodoItem[] | undefined;
/** Compact status-bar segment: progress count plus the active item. */
export declare function statusText(todos: TodoItem[]): string;
/** Full board for /todo — completed items render struck through. */
export declare function listText(todos: TodoItem[]): string;
/**
 * Surface the native todo board: a `ceulen:todo` status line refreshed at
 * turn boundaries, plus `/todo` for the full list with completed items
 * struck through. DSH owns todo_write; this module only reads the transcript
 * (no per-call tool event exists).
 */
export declare function apply(ctx: PluginContext): void;
//# sourceMappingURL=index.d.ts.map