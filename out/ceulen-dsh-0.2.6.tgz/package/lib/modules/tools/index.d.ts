/**
 * Tool-level deferral (M4-2): a tool held out of the prompt costs no schema
 * bytes on any turn, and `ceulen_tools` keeps it one call away.
 *
 * The DSH registry does allow runtime register/unregister (`register()` returns
 * the disposer), but `deferLoading: true` alone does not make a plugin tool
 * callable: on routes with tool updates the model activates a deferred tool
 * only after a `tool-addition` developer block, and no plugin seam writes one.
 * So the cold half is held in-process by `registerToolSafe` and dispatched
 * here instead of registered as a deferred schema.
 */
import type { PluginContext } from '../../core/types.js';
export declare const name = "ceulen-tools";
export declare const inject: string[];
export declare function apply(ctx: PluginContext): void;
//# sourceMappingURL=index.d.ts.map