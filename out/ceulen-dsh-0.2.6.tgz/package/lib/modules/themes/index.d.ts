import type { PluginContext } from '../../core/types.js';
export declare const name = "ceulen-themes";
export declare const inject: never[];
export declare function apply(ctx: PluginContext): void;
//# sourceMappingURL=index.d.ts.map