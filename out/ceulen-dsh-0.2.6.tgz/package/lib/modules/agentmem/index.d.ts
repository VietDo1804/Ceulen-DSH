import type { PluginContext } from '../../core/types.js';
export declare const name = "ceulen-agentmem";
export declare const inject: string[];
/** Pure: memories -> the brief block (`''` when nothing qualifies). */
export declare function composeBrief(memories: readonly unknown[], options: {
    maxChars: number;
    recencyDays: number;
    now?: number;
    header?: string;
}): string;
/** Resolve the brief once per session; a dead local store falls back to Munin. */
export declare function resolveAgentMemBrief(): Promise<string>;
/** The resolved block (tests, `/agentmem-status`). */
export declare function currentBrief(): string;
/** Test hook: forget the brief and the consecutive-call counter. */
export declare function resetAgentMemState(): void;
/** One `/context` line: the brief's exact char count, absent when disabled. */
export declare function briefStatusLine(): string;
export declare function apply(ctx: PluginContext): void;
//# sourceMappingURL=index.d.ts.map