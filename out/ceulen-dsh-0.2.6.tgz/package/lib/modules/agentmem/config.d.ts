import type { CeulenSettings } from '../../core/settings.js';
export declare const AGENTMEM_ENV_KEYS: readonly ["AGENTMEM_API_KEY", "AGENTMEM_PROJECT", "AGENTMEM_BASE_URL"];
export type AgentMemConfigSource = 'param' | 'env' | 'store' | 'global';
export interface AgentMemResolvedConfig {
    apiKey: string;
    projectId: string;
    baseUrl: string;
    sources: {
        apiKey: AgentMemConfigSource;
        projectId: AgentMemConfigSource;
        baseUrl: AgentMemConfigSource;
    };
}
/**
 * Precedence per field: explicit tool param > AGENTMEM_* env > DSH credential
 * store (key only) > the `agentmem` settings section. There is no default base
 * URL: an unconfigured AgentMem refuses to run rather than guess a server, and
 * a `base_url` override without its own `api_key` throws (a caller that
 * redirects the endpoint must own the credential).
 */
export declare function resolveAgentMemConfig(params: Record<string, unknown> | undefined, settings: CeulenSettings): AgentMemResolvedConfig;
//# sourceMappingURL=config.d.ts.map