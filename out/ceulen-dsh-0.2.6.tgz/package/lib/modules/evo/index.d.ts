import type { PluginContext } from '../../core/types.js';
import { pendingChanges } from './notice.js';
export declare const name = "ceulen-evo";
export declare const inject: string[];
export { noticeText, pendingChanges, type ChangeEntry } from './notice.js';
export declare function apply(ctx: PluginContext): void;
export declare const _test: {
    pendingChanges: typeof pendingChanges;
};
//# sourceMappingURL=index.d.ts.map