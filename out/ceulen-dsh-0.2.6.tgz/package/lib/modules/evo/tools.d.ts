import type { PluginContext, ToolRunContext } from '../../core/types.js';
import { type ChangeEntry } from './notice.js';
export interface EvoRuntime {
    /** Status-line flash owned by the root activation. */
    flash(text: string): void;
}
/** Record a change and deliver the notice to the live session when there is one. */
export declare function recordChange(runtime: EvoRuntime, exec: ToolRunContext | undefined, summary: string, detail?: string): {
    entry: ChangeEntry;
    delivered: boolean;
};
export declare function registerEvoTools(ctx: PluginContext, runtime: EvoRuntime): void;
//# sourceMappingURL=tools.d.ts.map