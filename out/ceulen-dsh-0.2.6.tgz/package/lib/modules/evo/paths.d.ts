/** `$DSH_HOME/ceulen/self-evo` — evo runtime state (ledger, reports, notices). */
export declare function evoDir(): string;
export declare function reportsDir(): string;
export declare function changelogPath(): string;
export declare function cursorPath(): string;
//# sourceMappingURL=paths.d.ts.map