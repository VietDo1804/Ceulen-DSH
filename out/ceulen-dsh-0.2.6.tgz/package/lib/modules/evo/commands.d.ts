import type { PluginContext } from '../../core/types.js';
/** The newest `report-<date>.md` and the line that sums up its fix groups. */
export declare function newestReport(): {
    file: string;
    headline: string;
} | undefined;
export declare function registerEvoCommands(ctx: PluginContext): void;
//# sourceMappingURL=commands.d.ts.map