import type { AgentLike } from '../../core/types.js';
export interface ChangeEntry {
    at: string;
    summary: string;
    detail?: string;
}
export declare function readChanges(): ChangeEntry[];
export declare function moveCursor(at: string): void;
/** Changes the user has not been shown yet. */
export declare function pendingChanges(): ChangeEntry[];
export declare function noticeText(entries: readonly ChangeEntry[]): string;
/** Append the notice to the live session without waking the model. */
export declare function deliver(agent: AgentLike, entries: readonly ChangeEntry[]): boolean;
/** Append one change to the changelog (the notice consumer moves the cursor). */
export declare function appendChange(summary: string, detail?: string): ChangeEntry;
//# sourceMappingURL=notice.d.ts.map