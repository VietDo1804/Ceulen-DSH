/**
 * Full-screen `/context --play` scene: the recorded context DNA, replayed.
 *
 * Registered through the TUI's `tuiScenes` seam. The host injects its own
 * React and ui kit, so this file imports no React and no dsh-tui package — a
 * headless composition never loads it. Colours are the host's semantic names,
 * never ANSI: the scene renders through `<Text color=…>`, not through the
 * registry-command path that `scripts/tui-context-patch.mjs` sanitizes.
 */
import { type DnaSnapshot } from './dna.js';
interface KeyFlags {
    upArrow: boolean;
    downArrow: boolean;
    leftArrow: boolean;
    rightArrow: boolean;
    pageUp: boolean;
    pageDown: boolean;
    wheelUp: boolean;
    wheelDown: boolean;
    home: boolean;
    end: boolean;
    return: boolean;
    escape: boolean;
    ctrl: boolean;
    shift: boolean;
    tab: boolean;
    backspace: boolean;
    delete: boolean;
    meta: boolean;
}
interface SceneReact {
    useState<T>(initial: T | (() => T)): [T, (value: T | ((previous: T) => T)) => void];
    useEffect(effect: () => void | (() => void), deps?: readonly unknown[]): void;
    createElement(type: unknown, props?: Record<string, unknown> | null, ...children: unknown[]): unknown;
}
interface SceneUi {
    Box: unknown;
    Text: unknown;
    useInput(handler: (input: string, key: KeyFlags) => void, options?: {
        isActive?: boolean;
    }): void;
    useTerminalSize(): {
        columns: number;
        rows: number;
    };
}
export interface SceneProps {
    React: SceneReact;
    ui: SceneUi;
    close(): void;
}
export interface DnaSceneOptions {
    /** Read on mount: the frames collected for the session that opened the scene. */
    snapshots(): readonly DnaSnapshot[];
    /** Replay speed, one frame per tick. Defaults to 140 ms. */
    intervalMs?: number;
}
export declare function createDnaScene(options: DnaSceneOptions): (props: SceneProps) => unknown;
export {};
//# sourceMappingURL=dna-scene.d.ts.map