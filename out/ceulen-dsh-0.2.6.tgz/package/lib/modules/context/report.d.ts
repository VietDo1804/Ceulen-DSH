import type { MessageLike } from '../../core/types.js';
export interface ContextUsage {
    windowTokens?: number;
    used: number;
    systemTokens: number;
    toolsTokens: number;
    messageTokens: number;
    bufferTokens?: number;
    estimated?: boolean;
}
export interface CompactionOptions {
    thresholdRatio?: number;
    headroomTokens?: number;
    reservedOutput?: number;
}
/**
 * The dsh-compaction-basic pressure trigger, restated as reserved space:
 * compaction arms at `min(W × ratio, W − reservedOutput − headroom)`, so the
 * buffer is everything above that line. Defaults mirror the plugin
 * (0.8 / 65536; reserved output comes from the resolved model cap).
 */
export declare function compactionBuffer(windowTokens: number, options?: CompactionOptions): number;
/** Options for the ANSI dashboard. Without `color` the report stays plain. */
export interface ReportOptions {
    /**
     * Emit the Claude Code-style colored dashboard. The TUI strips escape
     * sequences from registry reports; `scripts/tui-context-patch.mjs` asks for
     * this mode and keeps only SGR (color) sequences from the result.
     */
    color?: boolean;
    /** Terminal columns for the side-by-side fit; defaults to 120. */
    columns?: number;
}
/** The dashboard: ANSI card when asked for color, plain blocks otherwise. */
export declare function buildReport(usage: ContextUsage, header?: {
    displayName?: string;
    route?: string;
}, options?: ReportOptions): string;
/** Role-based fallback split when the breakdown projection is not composed. */
export declare function estimateBreakdown(messages: readonly MessageLike[]): {
    systemTokens: number;
    messageTokens: number;
};
//# sourceMappingURL=report.d.ts.map