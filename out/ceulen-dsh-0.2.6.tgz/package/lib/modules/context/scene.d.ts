import type { PluginContext } from '../../core/types.js';
import { type DnaSnapshot } from './dna.js';
/** `/context --play` scene, registered on first use like `/config`. */
export declare const DNA_SCENE_ID = "ceulen-context-dna";
/** The static frame, shown when no scene is mounted (headless, or a plain shell). */
export declare function dnaReport(snapshots: readonly DnaSnapshot[], options: {
    width: number;
    color: boolean;
}): string;
/** Point the mounted scene at this frame list and open it; false when no scene. */
export declare function openDnaReplay(ctx: PluginContext, snapshots: readonly DnaSnapshot[]): boolean;
//# sourceMappingURL=scene.d.ts.map