/**
 * `/context` — the Claude Code-style context dashboard. The split:
 *
 * - report.ts   public usage/report types, the compaction buffer, buildReport
 * - dashboard.ts ANSI card + plain block rendering, stripAnsi
 * - collect.ts  service reads (projections, token meter, model info) and reportFor
 * - scene.ts    the `/context --play` DNA scene plus its static fallback frame
 */
import type { PluginContext } from '../../core/types.js';
import { formatTokens } from './dna.js';
export declare const name = "ceulen-context";
export declare const inject: string[];
export { formatTokens };
export { buildReport, compactionBuffer, estimateBreakdown } from './report.js';
export type { CompactionOptions, ContextUsage, ReportOptions } from './report.js';
/**
 * `/context` — the Claude Code-style context dashboard: one block grid plus a
 * per-category token legend, built from the harness's own token meter and
 * session projections. The TUI claims `/context` locally, so
 * scripts/tui-context-patch.mjs redirects the built-in to this registry
 * command when it exists; it also passes `--color --width N` and keeps the
 * SGR sequences this command emits.
 *
 * `--dna` swaps the category grid for the per-item fingerprint (see dna.ts);
 * `--play` opens the replay scene when `tuiScenes` is mounted and falls back
 * to the same static frame otherwise.
 */
export declare function apply(ctx: PluginContext): void;
//# sourceMappingURL=index.d.ts.map