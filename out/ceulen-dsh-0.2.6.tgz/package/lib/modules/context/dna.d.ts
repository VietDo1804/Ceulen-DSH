/**
 * DNA mode — the context window as a per-item fingerprint.
 *
 * A text port of the `dsh-context` web visualization (bowenliang123/dsh-context):
 * one band per model-visible item in reading order (system prompt, the tool
 * schemas, then the messages) instead of one band per category, so a fat tool
 * result or a bloated tool schema is visible by name.
 *
 * Pricing mirrors `@deepseek-ai/dsh-token-meter`'s fixed-density estimate
 * (chars/4 plus per-block framing), so the band widths agree with the totals
 * the dashboard already shows. Nothing here imports the host: the collector
 * reads the session's plain event log.
 *
 * Each `request/header` freezes the surface the model saw at that call, and a
 * compaction drops the sequences it shadowed — which is the replay the scene
 * steps through.
 */
/** Categories, in the order the model reads them. */
export type DnaCategory = 'system' | 'tools' | 'messages' | 'other';
export interface DnaItem {
    /** Stable across requests (`sys:<seq>`, `tool:<name>`, `msg:<seq>`). */
    key: string;
    cat: DnaCategory;
    label: string;
    tokens: number;
}
export interface DnaSnapshot {
    /** Seq of the `request/header` this frame was assembled from. */
    seq: number;
    turn: number;
    time?: number;
    items: DnaItem[];
    total: number;
}
/** The subset of a session event the collector reads. */
export interface DnaEvent {
    seq?: number;
    type: string;
    time?: number;
    data?: unknown;
    surfaceOp?: string;
}
interface BlockLike {
    type?: unknown;
    text?: unknown;
    name?: unknown;
    arguments?: unknown;
}
interface MessageLike {
    role?: unknown;
    content?: readonly BlockLike[];
    source?: {
        callId?: unknown;
    };
}
/** Price one model-visible message the way the host meter does. */
export declare function priceMessage(message: MessageLike | undefined): number;
/** Price one tool schema on its own (the meter prices the whole array). */
export declare function priceTool(tool: unknown): number;
/** `1234` → `1.2K`, `1_000_000` → `1M` — the compact dashboard style. */
export declare function formatTokens(value: number): string;
export interface CollectOptions {
    /** Snapshots kept (the replay window). Defaults to 200. */
    limit?: number;
}
/**
 * Walk the session log once and freeze the surface at every `request/header`.
 *
 * A surface event appends its priced node; a `compaction/summary` or
 * `compaction/prune` drops the sequences it shadowed. Events without
 * `surfaceOp` are treated as appends, so pre-v4 logs still replay.
 */
export declare function collectSnapshots(events: readonly DnaEvent[], options?: CollectOptions): DnaSnapshot[];
/**
 * Spread `width` cells across `weights` proportionally: floor first, then hand
 * the remainder to the largest fractional parts. The bar is exactly `width`
 * cells wide, and a tiny item can round to zero (it still shows in the legend).
 */
export declare function allocate(weights: readonly number[], width: number): number[];
export interface GenomeOptions {
    width: number;
    /** Bands kept individually; the rest fold into one `other` band. Defaults to 24. */
    maxBands?: number;
}
export interface Band {
    key: string;
    label: string;
    cat: DnaCategory;
    tokens: number;
    cells: number;
}
/** Pick the bands that fit the width, preserving reading order. */
export declare function layoutGenome(snapshot: DnaSnapshot, options: GenomeOptions): Band[];
/** Glyph per category, matching the dashboard's block language. */
export declare const BAND_GLYPHS: Record<DnaCategory, string>;
/** Truecolor per category, matching the dashboard palette. */
export declare const BAND_COLORS: Record<DnaCategory, string>;
/** One genome row: a band per item, in the order the model reads them. */
export declare function renderGenome(snapshot: DnaSnapshot, options: GenomeOptions & {
    color?: boolean;
}): string;
/** `T3 · 41 items · 128.4K tokens` */
export declare function describeSnapshot(snapshot: DnaSnapshot, step?: {
    index: number;
    count: number;
}): string;
/** The biggest items, one line each — the legend beside the bar. */
export declare function renderItems(snapshot: DnaSnapshot, options?: {
    limit?: number;
    focus?: string;
    color?: boolean;
}): string[];
/** A full static frame: header, genome row, legend. Used when no scene is mounted. */
export declare function renderFrame(snapshot: DnaSnapshot, options?: GenomeOptions & {
    limit?: number;
    focus?: string;
    color?: boolean;
}): string[];
export {};
//# sourceMappingURL=dna.d.ts.map