import type { AgentLike, PluginContext } from '../../core/types.js';
import { type ReportOptions } from './report.js';
/** Structural views of the optional harness services this module reads. */
export interface ResolvedModelInfoLike {
    name?: string;
    id?: string;
    context?: {
        contextWindow?: number;
    };
    defaultMaxTokens?: number;
}
export interface LlmLike {
    resolveModelInfo?(provider: string, model: string): Promise<ResolvedModelInfoLike>;
}
/** Host state of token-meter's `contextPressure` projection unit. */
export interface PressureState {
    contextWindow?: number;
    pressureTokens?: number;
    surfaceTokens: number;
    sampledSurfaceTokens?: number;
}
/** Host state of token-meter's `contextBreakdown` projection unit. */
export interface BreakdownState {
    breakdown: {
        systemTokens: number;
        toolsTokens: number;
        messageTokens: number;
    };
}
export interface ProjectionsLike {
    stateOf?(session: unknown, key: string): unknown;
}
export interface MeterLike {
    measure(session: unknown): {
        totalTokens?: number;
        surfaceTokens?: number;
    };
}
export interface CompactionConfigLike {
    config?: {
        thresholdRatio?: number;
        headroomTokens?: number;
    };
}
/** The live TUI shares this process's stdout, so it reports the real width. */
export declare function terminalColumns(): number | undefined;
export declare function reportFor(ctx: PluginContext, agent: AgentLike, options?: ReportOptions): Promise<string>;
//# sourceMappingURL=collect.d.ts.map