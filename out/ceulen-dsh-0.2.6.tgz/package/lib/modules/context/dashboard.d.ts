import type { ContextUsage, ReportOptions } from './report.js';
export declare function isDashboardGlyph(char: string): boolean;
/** Visible terminal width of a styled line; the draughts glyphs are 2 cells. */
export declare function visibleWidth(text: string): number;
interface DashboardRow {
    key: 'system' | 'tools' | 'messages' | 'free' | 'buffer';
    label: string;
    tokens: number;
    color: string;
    glyph: string;
}
export declare function percent(part: number, whole: number): string;
export declare function dashboardRows(usage: ContextUsage, windowTokens: number): DashboardRow[];
/**
 * The right-hand column. It is exactly ten lines (model, route, total, blank,
 * heading, and the legend), so every line pairs with one grid row and the
 * panel never needs a continuation indent.
 */
export declare function dashboardPanel(usage: ContextUsage, header: {
    displayName?: string;
    route?: string;
}, windowTokens: number): string[];
/** The widest grid (20/10/5 columns) whose card still fits the terminal. */
export declare function dashboardColumns(windowTokens: number, panelWidth: number, columns: number | undefined): number;
/**
 * Per-category cell counts, rounded independently (a non-empty category keeps
 * one cell). Categories come first, free fills the middle, and the reserved
 * autocompact buffer closes the grid — the buffer is the end of the line.
 */
export declare function dashboardCells(rows: readonly DashboardRow[], windowTokens: number, total: number): Array<{
    color: string;
    glyph: string;
}>;
export declare function dashboardGrid(cells: ReadonlyArray<{
    color: string;
    glyph: string;
}>, cols: number): string[];
export declare function buildColoredReport(usage: ContextUsage, header: {
    displayName?: string;
    route?: string;
}, options: ReportOptions): string;
/**
 * The plain dashboard: header, proportional block grid, and the per-category
 * legend. Without a known window there is nothing to be proportional to —
 * the grid and the free/buffer rows are dropped.
 */
export declare function buildPlainReport(usage: ContextUsage, header?: {
    displayName?: string;
    route?: string;
}): string;
export declare function stripAnsi(text: string): string;
export {};
//# sourceMappingURL=dashboard.d.ts.map