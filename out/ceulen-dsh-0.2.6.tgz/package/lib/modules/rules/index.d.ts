import type { PluginContext } from '../../core/types.js';
import { type RuleModel } from '../../vendor/ceulen/rules/rules.js';
export declare const name = "ceulen-rules";
export declare const inject: string[];
/**
 * Sticky rules the prompt block had no room for. The vendor renderer drops a
 * rule whole once the block passes its cap and tells only the model, so the
 * owner of RULES.md never learns that a rule stopped applying.
 */
export declare function droppedSticky(model: RuleModel): string[];
/**
 * The string a guard tests: the command for `bash`, the target path for the
 * file editors (apply_patch carries its path inside the patch text), and the
 * JSON arguments for everything else.
 */
export declare function guardSubject(tool: string, args: unknown): string;
export declare function apply(ctx: PluginContext): void;
//# sourceMappingURL=index.d.ts.map