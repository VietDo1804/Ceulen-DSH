export interface UsageWindow {
    percent?: number;
    remaining?: number;
    remainingLabel?: string;
    resetLabel?: string;
}
export interface UsageAccount {
    id?: string;
    isActive?: boolean;
    accountLabel?: string;
    plan?: string;
    fiveHour?: UsageWindow;
    weekly?: UsageWindow;
    monthly?: UsageWindow;
    monthlyCredits?: number;
    creditsCurrency?: string;
    mcpMonthly?: UsageWindow;
    usageBreakdown?: string;
    lastActivity?: string;
}
export interface UsageSnapshot {
    providerDisplayName: string;
    accounts: UsageAccount[];
    activeAccount?: UsageAccount;
    fetchedAt: number;
    error?: string;
}
export interface UsageAdapter {
    id: string;
    displayName: string;
    fetchUsage(signal?: AbortSignal): Promise<UsageSnapshot>;
}
export declare function formatRemainingTime(resetAtSec: number | undefined): string | undefined;
export declare function formatReset(timestampSeconds: number | undefined): string | undefined;
export declare function opcWindowToUsageWindow(window: {
    percent?: number;
    resetsAt?: string;
} | undefined): UsageWindow | undefined;
export declare const openCodeGoAdapter: UsageAdapter;
export declare const zaiAdapter: UsageAdapter;
export declare const zaiCodingCnAdapter: UsageAdapter;
export declare const commandCodeAdapter: UsageAdapter;
export declare const codexAdapter: UsageAdapter;
export declare const routerAdapter: UsageAdapter;
export declare const ADAPTERS: readonly UsageAdapter[];
export declare function adapterFor(providerId: string | undefined): UsageAdapter | undefined;
export declare function configuredAdapters(): UsageAdapter[];
export declare function formatMonthlyCredits(amount: number, currency?: string): string;
export declare function detailLines(snapshot: UsageSnapshot, options?: {
    tokenLine?: string;
}): string[];
export declare function compactLine(snapshot: UsageSnapshot): string | undefined;
//# sourceMappingURL=providers.d.ts.map