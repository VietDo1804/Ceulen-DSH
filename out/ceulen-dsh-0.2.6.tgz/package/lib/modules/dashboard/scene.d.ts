import { type DashboardChannel } from './model.js';
interface Key {
    escape?: boolean;
    tab?: boolean;
    shift?: boolean;
    return?: boolean;
    upArrow?: boolean;
    downArrow?: boolean;
    pageUp?: boolean;
    pageDown?: boolean;
    home?: boolean;
    end?: boolean;
    ctrl?: boolean;
}
export interface SceneProps {
    React: {
        createElement(type: unknown, props?: Record<string, unknown> | null, ...children: unknown[]): unknown;
        useState<T>(initial: T | (() => T)): [T, (next: T | ((previous: T) => T)) => void];
        useEffect(effect: () => void | (() => void), deps: readonly unknown[]): void;
        useRef<T>(value: T): {
            current: T;
        };
    };
    ui: {
        Box: unknown;
        Text: unknown;
        ScrollBox: unknown;
        useInput(handler: (input: string, key: Key) => void): void;
        useTerminalSize(): {
            columns: number;
            rows: number;
        };
    };
    channel: DashboardChannel;
    close(): void;
}
export declare function layout(columns: number, rows: number): 'small' | 'tabs' | 'stacked' | 'wide';
/** A rebind remounts local navigation, never reuses another session's snapshot. */
export declare function createDashboardScene(): (props: SceneProps) => unknown;
export {};
//# sourceMappingURL=scene.d.ts.map