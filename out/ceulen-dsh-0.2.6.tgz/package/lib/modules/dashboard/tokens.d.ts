/** Terminal-cell mapping of tui-dashboard/DESIGN.md; font belongs to the terminal. */
export declare const tokens: {
    readonly page: "#0B0F12";
    readonly panel: "#10151D";
    readonly text: "#DEDDE6";
    readonly muted: "#CACDD6";
    readonly lead: "#B9ADFF";
    readonly builder: "#FFC09B";
    readonly tester: "#A5D2FF";
    readonly success: "#74E698";
    readonly warning: "#F0CF72";
    readonly danger: "#FFC0C0";
    readonly border: "#525967";
    readonly inset: 1;
    readonly wide: 120;
    readonly stacked: 80;
    readonly minColumns: 30;
    readonly minRows: 10;
};
//# sourceMappingURL=tokens.d.ts.map