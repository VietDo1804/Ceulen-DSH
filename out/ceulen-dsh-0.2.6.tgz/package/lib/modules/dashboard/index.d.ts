import type { PluginContext } from '../../core/types.js';
export declare const name = "ceulen-dashboard";
export declare const inject: string[];
export declare const SCENE_ID = "ceulen-dashboard";
export declare function apply(ctx: PluginContext): void;
//# sourceMappingURL=index.d.ts.map