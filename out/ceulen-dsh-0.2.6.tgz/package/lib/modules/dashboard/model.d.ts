/** Narrow, read-only views of the host channel. No runtime/TUI dependency. */
export interface Task {
    id: string;
    subject: string;
    description?: string;
    status: string;
    ownerName?: string;
    blockedBy: readonly string[];
    writeScopes: readonly string[];
    writeScopeWarnings: readonly string[];
    ready: boolean;
}
export interface Team {
    enabled?: boolean;
    failure?: string;
    tasks: readonly Task[];
    members?: readonly {
        id: string;
        name: string;
        role: string;
        phase: string;
    }[];
}
export interface Child {
    agentId: string;
    sessionId?: string;
    runId?: string;
    name?: string;
    description?: string;
    provider?: string;
    model?: string;
    status: string;
    startedAt?: number;
    endedAt?: number;
    completedAt?: number;
    reportedDurationMs?: number;
    lastTool?: string;
    toolCalls?: readonly {
        name: string;
        status: string;
        startedAt: number;
    }[];
    outputEvents?: readonly {
        kind: string;
        text: string;
        at: number;
    }[];
    tokens?: {
        input?: number;
        output?: number;
        total?: number;
    };
    settledRuns?: readonly {
        runId?: string;
        status: string;
    }[];
}
export interface DashboardChannel {
    sessionId: string;
    agentId?: string;
    agentBindingGeneration?: number;
    provider?: string;
    model?: string;
    status?: string;
    team?: Team;
    tokens?: {
        input?: number;
        output?: number;
    };
    subagents?: readonly Child[];
    rows?: readonly {
        id: number;
        kind: string;
        tool?: {
            name: string;
            status: string;
            startedAt?: number;
        };
    }[];
    agentViewRows?(): readonly {
        id: string;
        status: string;
    }[];
    subscribe?(listener: () => void): () => void;
    subscribeAgentView?(listener: () => void): () => void;
}
export interface Item {
    id: string;
    title: string;
    status: string;
    meta: string;
    detail: readonly string[];
}
export interface Dashboard {
    sessionId: string;
    lead: string;
    warning?: string;
    failure?: string;
    needsInput: boolean;
    taskCount: string;
    tasks: readonly Item[];
    agents: readonly Item[];
    activity: readonly Item[];
}
/** Host Text owns Unicode cell measurement/truncation; strip control bytes first. */
export declare function clean(value: unknown, limit?: number): string;
export declare function project(channel: DashboardChannel, now?: number): Dashboard;
export declare function summary(view: Dashboard): string;
/** Every listener belongs to one mount, including the separate agent-view feed. */
export declare function watch(channel: DashboardChannel, listener: () => void): () => void;
//# sourceMappingURL=model.d.ts.map