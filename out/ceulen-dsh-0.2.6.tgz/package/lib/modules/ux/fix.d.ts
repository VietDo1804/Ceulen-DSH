import { type AuditPairResult } from '../../vendor/ceulen/ux/audit.js';
export interface ColourFix {
    /** Suggested replacement value. */
    color: string;
    /** APCA Lc of the suggestion against the same background. */
    apca: number;
    /** Existing token that already passes, when one exists. */
    token?: string;
}
/**
 * Nearest passing colour with the same hue and saturation: walk lightness away
 * from the background, one percent at a time, and stop at the first pass.
 */
export declare function suggestColour(fg: string, bg: string, apcaMin: number, wcagMin?: number, tokens?: Map<string, string>): ColourFix | null;
/** Closest system token to an off-system value (first name when several share it). */
export declare function nearestToken(value: string, tokens: Map<string, string>): {
    name: string;
    value: string;
} | null;
export declare function contrastFixLine(pair: AuditPairResult, tokens?: Map<string, string>): string;
//# sourceMappingURL=fix.d.ts.map