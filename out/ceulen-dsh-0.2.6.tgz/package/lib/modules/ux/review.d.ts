export type Severity = 'high' | 'medium' | 'low';
export interface RuntimeFinding {
    severity: Severity;
    check: string;
    message: string;
    detail?: string;
}
export interface MotionSummary {
    /** Distinct CSS animation names in use. */
    animations: number;
    /** Distinct element kinds that declare a transition. */
    transitions: number;
    /** Animations tied to scroll position, which have no clock to sample. */
    scrollLinked: number;
}
export interface RuntimeAudit {
    url: string;
    viewports: number[];
    /** Deduped across viewports; `seenAt` lists the widths where it fired. */
    findings: Array<RuntimeFinding & {
        seenAt: number[];
    }>;
    /** PNG base64 for the two viewports worth showing the model. */
    shots: Array<{
        width: number;
        base64: string;
    }>;
    /** What the stylesheets declare outside the reduced-motion fallback. */
    motion?: MotionSummary;
    /** Page-load animation frames, only when `motion` was requested. */
    frames?: Array<{
        at: number;
        base64: string;
    }>;
    /** Why no frames came back, when frames were requested. */
    framesNote?: string;
    /** Set when the page could not be rendered at all (no PASS is claimed). */
    inconclusive?: string;
}
/** Validates the caller's tier list: 320–3840 px, deduped, ascending, max 6. */
export declare function resolveViewports(input: unknown): number[];
/**
 * Runs in the page, not in Node. `runRuntimeAudit` sends `pageChecks.toString()`
 * through CDP, so this function must stay self-contained: no imports, no
 * module-scope constants.
 */
export declare function pageChecks(): RuntimeFinding[];
/**
 * Runs in the page, self-contained like `pageChecks`. Only a page written in
 * Vietnamese is checked: ă đ ơ ư and U+1EA0–U+1EF9 occur in no other language,
 * so English, French or Portuguese copy never triggers it.
 *
 * - `vi-glyphs`: a font without Vietnamese glyphs. The browser takes the letter
 *   from another font, or breaks ế into ê plus a loose accent. A web font's
 *   `unicode-range` says what it covers (Google Fonts serves a `vietnamese`
 *   subset only for families that have one); any other font is compared
 *   against two different fallbacks, which agree only when it drew the letter.
 * - `vi-fallback`: a fallback font with no Vietnamese (Georgia, Futura…): while
 *   the web font loads, or if it fails, ầ shows as "â`".
 * - `vi-mixed-font`: one family drawn by two typefaces, Vietnamese letters from
 *   one and the rest from another, so a word mixes designs.
 * - `vi-line-height`: a wrapped headline where the ink of a letter, marks
 *   included, touches the ink of the letter above it, descenders, dots below
 *   and commas included, so Ấn reads as Ận or Ổ sits on a comma.
 */
export declare function vietnameseChecks(): Promise<RuntimeFinding[]>;
/** The colours a page really shows, by how much of it they cover. */
export declare function paletteChecks(): Array<{
    hex: string;
    share: number;
    kind: 'surface' | 'text';
}>;
/** Colours covering a real part of the page that are nowhere near DESIGN.md. */
export declare function offPalette(shown: ReturnType<typeof paletteChecks>, design: string): string[];
/**
 * Runs in the page, like pageChecks, so it must stay self-contained. Reads
 * computed styles, not stylesheet rules: Chrome throws SecurityError on
 * `sheet.cssRules` for an external stylesheet opened over file://, which would
 * report a page full of motion as static. Needs a load with motion on, so the
 * reduced-motion fallback does not hide what it is meant to measure.
 */
export declare function motionChecks(): {
    findings: RuntimeFinding[];
    animations: number;
    transitions: number;
    scrollLinked: number;
};
/**
 * What only shows with motion on and a reader scrolling: list items that arrive
 * as they come in. Runs last, after the frames, because it scrolls.
 */
export declare function arrivalChecks(): Promise<{
    findings: RuntimeFinding[];
    items: number;
    arrived: number;
}>;
/**
 * Time labels on a drawn chart must agree with each other, and a peak named in
 * the text must sit on the line. No label is trusted alone: the fit that most
 * labels agree on decides. Edges use offsetWidth, because a mark frozen at the
 * start of its arrival is scaled down around its centre.
 */
export declare function chartChecks(): {
    findings: RuntimeFinding[];
};
/** Freezes every running animation at its start and reports the timeline. */
/**
 * An app paints after load, so a check that runs at load reads an empty page and
 * reports what is missing from it. Waits for visible text, then for the page to
 * stop changing for `quietMs`, capped so a live page cannot hold the audit. A
 * page with no scripts has nothing to wait for.
 */
export declare const settleStep: (quietMs: number) => string;
/** The two widths a model should actually look at: smallest phone, widest ≤1440. */
export declare function screenshotWidths(viewports: number[]): number[];
export declare const SCROLL_STEP = "(async () => {\n  const step = window.innerHeight;\n  for (let y = 0; y < document.documentElement.scrollHeight; y += step) {\n    window.scrollTo(0, y);\n    await new Promise((resolve) => setTimeout(resolve, 30));\n  }\n  window.scrollTo(0, 0);\n  await new Promise((resolve) => setTimeout(resolve, 60));\n  return true;\n})()";
/** Opens the page at every tier and merges identical findings across widths. */
export declare function runRuntimeAudit(options: {
    url: string;
    cwd: string;
    viewports?: number[];
    motion?: boolean;
    design?: string;
    signal?: AbortSignal;
}): Promise<RuntimeAudit>;
export declare function formatRuntimeReport(audit: RuntimeAudit): string;
//# sourceMappingURL=review.d.ts.map