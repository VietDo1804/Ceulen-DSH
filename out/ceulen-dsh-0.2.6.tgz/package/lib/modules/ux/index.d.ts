import type { PluginContext, ToolRunContext } from '../../core/types.js';
import { type AuditResult } from '../../vendor/ceulen/ux/audit.js';
export declare const name = "ceulen-ux";
export declare const inject: string[];
/**
 * Resolve the stylesheet to audit: a file `path` read verbatim (preferred —
 * retyped copies drift and produce false passes) or inline `css` text.
 * Exactly one. A run with neither AND no `pairs` would scan nothing and pass
 * three gates vacuously, so it is an error rather than an empty audit.
 * `pairs` alone is a real contrast-only check, not a vacuous run.
 */
export declare function resolveAuditCss(params: {
    css?: unknown;
    path?: unknown;
    pairs?: unknown;
}, cwd: string): Promise<string>;
/** A call carries a stylesheet when it names `path`, `css`, or `pairs`. */
export declare function hasStylesheet(args: {
    css?: unknown;
    path?: unknown;
    pairs?: unknown;
    url?: unknown;
}): boolean;
/**
 * Runtime mode may run on its own or alongside the static gates (two labelled
 * verdicts). Exported for the tool-contract test.
 */
export declare function runtimeUrlOf(args: {
    url?: unknown;
}): string | undefined;
/** A route with no declared input modalities is treated as image-capable. */
export declare function modelAcceptsImages(info: {
    inputModalities?: readonly string[];
} | undefined): boolean;
/** Whether the active route can receive the captured screenshots. */
export declare function routeAcceptsImages(ctx: PluginContext, exec?: Pick<ToolRunContext, 'agent' | 'signal'>): Promise<boolean>;
export interface AuditToolOutput {
    text: string;
    images?: unknown[];
}
/**
 * Static verdict, one line per finding, and the colour to use instead.
 * No appended JSON: the reported defect was ~1k tokens of duplicated gates.
 */
export declare function formatStylesheetReport(result: AuditResult, options?: {
    tokens?: Map<string, string>;
    contrastOnly?: boolean;
}): string;
/**
 * Colours DESIGN.md lists that the stylesheet no longer has. A stylesheet that
 * lacks half or more of them is only part of the system, so nothing is claimed.
 */
export declare function staleDesignColours(design: string, css: string): string[];
export declare function apply(ctx: PluginContext): void;
//# sourceMappingURL=index.d.ts.map