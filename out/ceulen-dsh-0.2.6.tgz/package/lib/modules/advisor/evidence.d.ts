import type { MessageLike } from '../../core/types.js';
/** File paths this turn's edit/write/apply_patch calls touched. */
export declare function touchedPaths(messages: readonly MessageLike[]): string[];
/**
 * Working-tree evidence for the reviewer: status, stat, and the diff of only
 * the files this turn touched. Old work-in-progress would raise concerns the
 * current request cannot answer, and one wrong concern costs ~7 steps.
 * Never throws; returns '' when there is nothing to show.
 */
export declare function gitEvidence(cwd: string | undefined, touched: readonly string[], signal?: AbortSignal, maxChars?: number): Promise<string>;
//# sourceMappingURL=evidence.d.ts.map