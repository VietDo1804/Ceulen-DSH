import type { MessageLike } from '../../core/types.js';
export declare const WATCH_BUDGET = 20000;
export declare const CONSULT_BUDGET = 16000;
/** A real human prompt: notices (time-context, approvals, …) never qualify. */
export declare function isUserPrompt(message: MessageLike): boolean;
/**
 * A new prompt or a delivered advisor note starts a fresh unit of work. Both
 * must reset the tool-call counter: a note-only reply after a concern is a
 * settled turn, not a continuation, or the advisor would review its own notes.
 */
export declare function isTurnBoundary(message: MessageLike): boolean;
/** Count tool calls since the last turn boundary. */
export declare function toolCallsInTurn(messages: readonly MessageLike[]): number;
/**
 * Render the latest turn with the user's request pinned at the top. The turn
 * body is clipped from the front when over budget — the agent's answer is at
 * the end — while the pinned request is never clipped for budget reasons.
 */
export declare function renderTurn(messages: readonly MessageLike[], budget: number): {
    text: string;
    pinned: boolean;
};
//# sourceMappingURL=transcript.d.ts.map