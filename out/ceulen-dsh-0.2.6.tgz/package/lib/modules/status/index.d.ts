import type { PluginContext } from '../../core/types.js';
/**
 * Whether the optional dsh-tui patches are applied (per-model effort, advisor transcript block,
 * /context redirect, tool-name aliases, plan-mode polish). They live in the
 * installed profile tree, so a dsh-tui update silently reverts them;
 * `/ceulen doctor` must make that visible instead of letting the loss rot
 * until someone notices a missing segment.
 *
 * Each marker below mirrors the anchor a patch script's `check` uses; when an
 * anchor moves in scripts/tui-*-patch.mjs, update the marker here too.
 */
export declare function tuiFooterState(): string;
/** The schema budget line: how many tools, how many bytes, and where they go. */
export declare function toolsText(ctx: PluginContext): string;
/** The Central status/settings surface for the bundle. */
export declare const name = "ceulen-status";
export declare const inject: string[];
export declare function apply(ctx: PluginContext): void;
//# sourceMappingURL=index.d.ts.map