import type { AgentLike, PluginContext } from '../../core/types.js';
import { type LlmRoute } from '../../core/llm.js';
import { type Judge } from '../../vendor/ceulen/jfind/questions.js';
export declare function createLlmJudge(ctx: PluginContext, route: LlmRoute): Judge;
export declare function routeFor(agent: AgentLike | undefined): LlmRoute;
//# sourceMappingURL=judge.d.ts.map