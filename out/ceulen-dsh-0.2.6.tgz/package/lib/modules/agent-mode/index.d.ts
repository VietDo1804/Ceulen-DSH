import type { PluginContext } from '../../core/types.js';
export declare const name = "ceulen-agent-mode";
export declare const inject: string[];
export declare function apply(ctx: PluginContext, config?: {
    path?: string;
}): void;
//# sourceMappingURL=index.d.ts.map