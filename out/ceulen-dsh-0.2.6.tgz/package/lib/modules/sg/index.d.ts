import type { PluginContext } from '../../core/types.js';
export declare const name = "ceulen-sg";
export declare const inject: string[];
export declare function apply(ctx: PluginContext): void;
//# sourceMappingURL=index.d.ts.map