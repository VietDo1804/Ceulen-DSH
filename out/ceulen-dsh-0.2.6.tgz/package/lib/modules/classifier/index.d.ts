import type { PluginContext } from '../../core/types.js';
export declare const name = "ceulen-classifier";
export declare const inject: string[];
export declare function isRisky(command: string): boolean;
export declare function isIrreversible(command: string): boolean;
/**
 * Enforce-mode reading of a command the shell cannot even parse. `bash -n`
 * parses without executing; an unterminated heredoc gets an empty stdin so it
 * fails instead of hanging. Denying is safe — bash would reject the command
 * anyway, and the caller gets a reason instead of a shell syntax error. A
 * missing or wedged bash also fails closed.
 */
export declare function isUnparseable(command: string): boolean;
export declare const GATE_THRESHOLD = 0.5;
/**
 * Working-tree summary for the gate state. Without it the model cannot tell a
 * clean-tree `git reset --hard` from one that drops uncommitted work.
 */
export declare function repoStatus(cwd: string): string;
export interface Question {
    id: string;
    type: 'noul' | 'choice' | 'score';
    instructions: string;
    criteria?: unknown;
}
/**
 * Models sometimes key the answer by question *type* ("noul") instead of *id*
 * ("safe") — accept either, then normalize to the id the caller reads.
 */
export declare function normalizeAnswers(parsed: unknown, questions: readonly Question[]): Record<string, unknown>;
export declare function apply(ctx: PluginContext): void;
//# sourceMappingURL=index.d.ts.map