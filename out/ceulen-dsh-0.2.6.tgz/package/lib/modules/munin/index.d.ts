import type { PluginContext } from '../../core/types.js';
export declare const name = "ceulen-munin";
export declare const inject: string[];
/** Pure: memories -> the brief block (`''` when nothing qualifies). */
export declare function composeBrief(memories: readonly unknown[], options: {
    maxChars: number;
    recencyDays: number;
    now?: number;
}): string;
/** Resolve the brief once per session; any failure yields `''`. */
export declare function resolveMuninBrief(cwd?: string): Promise<string>;
/** The resolved block (tests, `/munin-status`). */
export declare function currentBrief(): string;
/** One `/context` line: the brief's exact char count, absent when disabled. */
export declare function briefStatusLine(): string;
export declare function apply(ctx: PluginContext): void;
//# sourceMappingURL=index.d.ts.map