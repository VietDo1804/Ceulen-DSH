/**
 * Detects runs of consecutive steps that each make exactly one read-only call
 * — the pattern the codemode-first rule wants folded into one script or one
 * parallel batch. Pure state machine; the wiring lives in index.ts.
 */
export interface ChainState {
    stepKey?: string;
    stepCalls: number;
    stepReadOnly: boolean;
    /** Short label of the current step's first call, kept for the hint text. */
    stepLabel?: string;
    chain: number;
    /** Labels of the lone read steps in the current chain, oldest first. */
    chainLabels: string[];
    hintedTurn?: number;
    /** The chain that triggered the last hint; index.ts renders it. */
    hintedLabels: string[];
}
export declare const HINT = "Put the next independent reads, or the whole grep \u2192 read \u2192 filter chain, into one codemode script or one parallel tool batch.";
export declare function createChainState(): ChainState;
export declare function isReadOnlyCall(name: string, argumentsJson: string | undefined): boolean;
/** `read src/a.ts`, `bash git log …`: the call as the model would recognise it. */
export declare function callLabel(name: string, argumentsJson: string | undefined): string;
/**
 * The injected notice names the steps it is about: a concrete list is acted on
 * more often than a generic reminder. Measured 2026-11-08: the generic hint was
 * followed by a codemode script 4 times out of 14.
 */
export declare function hintText(labels: readonly string[]): string;
/**
 * Feed every `tool/call` event. Returns true when the chain reached the
 * threshold and a hint should be injected for this turn (at most once a turn);
 * `state.hintedLabels` then holds the steps the hint is about.
 */
export declare function noteToolCall(state: ChainState, call: {
    turn: number;
    step: number;
    name: string;
    arguments?: string;
}, threshold: number): boolean;
//# sourceMappingURL=chain-hint.d.ts.map