/** The script's return + console block budget, and its bounds. */
export declare const DEFAULT_OUTPUT_BUDGET = 6000;
export declare const MIN_OUTPUT_BUDGET = 200;
export declare const MAX_OUTPUT_BUDGET = 50000;
/** Per-call deadline bounds; the provider caps at maxTimeoutMs (default 600s). */
export declare const MIN_TIMEOUT_MS = 1000;
export declare const MAX_TIMEOUT_MS = 600000;
export interface ScriptOptions {
    timeoutMs?: number;
    maxOutputChars?: number;
}
/**
 * Pi's `// @options:` first line. Only the first line is honored; a malformed
 * or misplaced line fails the call before the program runs.
 */
export declare function parseOptionsLine(code: string): ScriptOptions;
/**
 * Pi's max_output_tokens shape: keep the head and tail of an oversized
 * return+console block, note how much was cut, and spill the full text to a
 * temp file whose path stays in the result. The runtime's hard byte cap
 * (output-limit) never fires for a model that stays anywhere near the budget.
 */
export declare function applyOutputBudget(valueText: string, consoleBlock: string, cap: number): {
    text: string;
    spillPath?: string;
};
/**
 * Pi ships errors that teach recovery: a `tools.Bash is not a function`
 * message names the close binding match so the script can self-correct in the
 * next call instead of guessing.
 */
export declare function suggestBinding(message: string, names: readonly string[]): string | undefined;
/** A recovery line for the failure classes the session logs show most. */
export declare function scriptErrorHint(kind: string, message: string): string | undefined;
/** `codemode.exit()` unwinds by throwing this; the executor turns it into a success. */
export declare const EXIT_SENTINEL = "codemode: exit() called";
/**
 * Pi trims a failed script's stack to one frame in its own codemode.js; the PTC
 * runtime sends the whole `error.stack`, which is mostly Node internals that
 * teach the model nothing. Keep the message and the first frame inside the
 * script (`<anonymous>:line:column`) so the model can find the failing line of
 * the code it wrote. A message with no frames passes through unchanged.
 */
export declare function trimScriptError(message: string): string;
//# sourceMappingURL=script.d.ts.map