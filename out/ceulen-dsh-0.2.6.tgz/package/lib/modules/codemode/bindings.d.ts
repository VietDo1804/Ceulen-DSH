import type { BindingNamespace, Json } from './types.js';
/**
 * Pi's `exit()`, in the one shape the PTC runtime allows: a namespace binding
 * that unwinds by throwing a sentinel the executor recognizes, so a nested
 * helper can end the script successfully. The transport requires a lossless
 * JSON argument (`null`) and `await` so the rejection unwinds at the call site
 * — a floating `codemode.exit(null)` never reaches the executor. Normal
 * success rules apply: pending store writes commit, console lines survive.
 */
export declare function exitBindings(): BindingNamespace;
/** Drop one session's committed state when its agent is disposed. */
export declare function forgetState(sessionId: string): void;
/** Merge one successful script's writes into its session's store. */
export declare function commitState(session: unknown, pending: Map<string, Json>): void;
/**
 * `state.store({ key, value })` / `state.load({ key })`: small JSON values that
 * survive across codemode calls of one live session (see {@link STORES}); a
 * script's writes apply only when that script succeeds, like Pi.
 */
export declare function stateBindings(session: unknown, success: {
    pending: Map<string, Json>;
}): BindingNamespace;
//# sourceMappingURL=bindings.d.ts.map