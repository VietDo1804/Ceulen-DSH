/**
 * Pi's `codemode`, ported onto the DSH PTC runtime.
 *
 * The model writes one JavaScript program; every visible tool is bound as
 * `tools.<name>(args)` and the program's return value plus console output are
 * the only things that reach the model. Execution, isolation, the deadline and
 * the output cap belong to `ctx.ptcRuntime` (dsh-ptc-runtime-node), so this
 * module owns only the tool surface, the bindings and the result text.
 *
 * Nested calls go through `ctx.tools.execute()`, not a ToolDefinition, so
 * pre-execute policy, guards, approvals and output validation still run.
 *
 * The split: types.ts (transport shapes), script.ts (options line, budget,
 * error trimming), bindings.ts (`codemode.exit`, `state.*`), render.ts (the
 * receipt/card text). This file is the registration and the execute pipeline.
 */
import type { PluginContext } from '../../core/types.js';
export declare const name = "ceulen-codemode";
export declare const inject: string[];
export declare function apply(ctx: PluginContext): void;
//# sourceMappingURL=index.d.ts.map