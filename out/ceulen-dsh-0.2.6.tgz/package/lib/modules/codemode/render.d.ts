import type { ToolRunContext } from '../../core/types.js';
import { type BindingFunction, type CodemodeCall, type PtcRunResult, type RegistryLike } from './types.js';
/** One short line for a card row; never a multi-line paste. */
export declare function clipOneLine(value: string, max?: number): string;
/** DSH's own duration format: `8ms`, `1.2s`, `2m5s`. */
export declare function formatMs(ms: number): string;
/**
 * The call's arguments the way the receipt shows them: compact JSON with the
 * boilerplate label keys dropped, clipped to one line.
 */
export declare function argSummary(args: unknown): string;
/** The nested-call ledger above the script output in the settled card. */
export declare function formatCalls(calls: readonly CodemodeCall[]): string;
/**
 * Bind every tool the calling agent can see. Names are passed through
 * unchanged: the model uses bracket access for names that are not identifiers,
 * which avoids the silent alias collisions Pi's `_` normalization can create.
 * The step's `toolSet` rides along on both the listing and every nested call,
 * so a conditional tool is bound exactly when this step admitted it.
 */
export declare function toolBindings(registry: RegistryLike, exec: ToolRunContext, calls: CodemodeCall[], usage?: {
    rawChars: number;
}): Record<string, BindingFunction>;
export declare const STATUS_LINE: RegExp;
/** Model-only advice: a single unfiltered call should have been a direct call. Lines start with this prefix. */
export declare const SINGLE_CALL_NOTE = "Note: one tool call with no real filtering";
/** Pi's result shape: status line, budgeted return value + console block, then the error. */
export declare function renderResult(result: PtcRunResult, wallSeconds: number, budget: number, calls?: readonly CodemodeCall[], rawChars?: number): {
    text: string;
    spillPath?: string;
};
/** The card renders its own receipt; drop the model-only notes from its body. */
export declare function stripModelNotes(body: string): string;
export declare function scriptTail(code: string): string;
//# sourceMappingURL=render.d.ts.map