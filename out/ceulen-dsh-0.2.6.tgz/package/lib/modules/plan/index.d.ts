import type { AgentLike, MessageLike, PluginContext, SessionLike } from '../../core/types.js';
import { type ReasoningEffort } from '../../core/settings.js';
export declare const name = "ceulen-plan";
export declare const inject: string[];
export declare const PLANS_DIR = ".dsh/plans";
export declare const CURRENT_OPTION = "Implement in current session";
export declare const NEW_SESSION_OPTION = "Clear context and implement in new session";
export declare const STAY_OPTION = "Continue planning";
export interface DraftPlan {
    readonly plan: string;
    readonly title: string;
}
interface SavedPlan {
    readonly path: string;
    readonly title: string;
    readonly content: string;
}
/** The newest `exit_plan_mode` call wins; its `plan` argument is the markdown.
 * The paired tool result is not inspected — a call that failed outside plan
 * mode still carries the draft, and saving it is harmless (last write wins). */
export declare function latestPlan(messages: readonly MessageLike[]): DraftPlan | undefined;
/** Ceulen's slug: lowercase, non-alphanumerics collapsed, trimmed to 60. */
export declare function planSlug(title: string): string;
export declare function planFileName(title: string, now?: Date): string;
/** Same title → refine the existing file; new title → a fresh timestamped one. */
export declare function planPathFor(cwd: string, title: string, previous?: SavedPlan): string;
/** Port of ceulen's buildExecutionPrompt. */
export declare function executionPrompt(relativePlan: string, mode: 'current' | 'new'): string;
interface PhaseRoute {
    readonly provider: string;
    readonly model: string;
    readonly reasoningEffort?: ReasoningEffort;
}
/** A configured phase route: `provider/model[:effort]`, or undefined for inherit. */
export declare function phaseRoute(selector: string): PhaseRoute | undefined;
/** Whether this session holds a submitted plan — an `exit_plan_mode` draft or
 * the execution handoff a fresh approved session starts with. */
export declare function hasApprovedPlan(session: SessionLike | undefined): boolean;
/**
 * Apply the configured route for the phase the session is in, through the
 * Agent's own durable selection seam (`agent.model.select`). DSH 0.2.2 freezes
 * a step's selection before preparation and throws when the `agent/request`
 * waterfall proposes a different provider/model ("use agent.model.select()
 * before step preparation"), so the route is chosen on a phase flip rather
 * than per request.
 *
 * A client model switch during a phase stands the override down until the
 * phase flips, so `/model` is never silently undone by a stale config.
 */
export declare function installPhaseRoutes(ctx: PluginContext, agent: AgentLike): void;
export declare function apply(ctx: PluginContext): void;
export {};
//# sourceMappingURL=index.d.ts.map