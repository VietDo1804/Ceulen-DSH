import type { SchemaNode } from './schema.js';
import { type ReasoningEffort } from '../../core/settings.js';
export interface RoleDefinition {
    readonly name: string;
    readonly description: string;
    /** Function alias (`@fast`, `@coder`, `@smart`); overridable per role. */
    readonly model: string;
    readonly thinking: ReasoningEffort;
    readonly persona: string;
}
export interface RoleSettings {
    readonly roles: Readonly<Record<string, readonly string[]>>;
    readonly models: Readonly<Record<string, string>>;
    readonly thinking: Readonly<Record<string, ReasoningEffort>>;
}
export interface RoleRoute {
    readonly provider: string;
    readonly model: string;
    readonly reasoningEffort?: ReasoningEffort;
}
export interface RoleResolution {
    readonly role: RoleDefinition;
    /** Selector that started the chain: the settings override or the role alias. */
    readonly selector: string;
    /** Expanded candidate routes, in priority order. */
    readonly candidates: readonly string[];
    /** First valid route; absent means "inherit the parent agent's route". */
    readonly route?: RoleRoute;
    readonly thinking: ReasoningEffort;
    readonly unresolved: readonly string[];
}
/** Split a trailing `:effort`; unknown suffixes (e.g. `:free`) stay in the name. */
export declare function splitThinkingSuffix(entry: string): {
    name: string;
    thinking?: ReasoningEffort;
};
export interface ExpandedChain {
    readonly candidates: string[];
    readonly thinkingByCandidate: Map<string, ReasoningEffort>;
    readonly unresolved: string[];
}
/**
 * Expand function aliases in place (cycle-safe) and drop parent references.
 * An alias's `:effort` suffix applies to every route it expands to; a route's
 * own suffix wins.
 */
export declare function expandChain(entries: readonly string[], roles: Readonly<Record<string, readonly string[]>>): ExpandedChain;
/** Static role catalog, in upstream order. */
export declare const ROLES: readonly RoleDefinition[];
/**
 * Default reply schema for the reviewer role (M3-2): a parent reads a verdict
 * and prioritised findings instead of parsing paragraphs. `delegate` appends
 * it to the child prompt and `validate_schema` checks the reply.
 */
export declare const REVIEWER_SCHEMA: SchemaNode;
export declare function roleByName(name: string): RoleDefinition | undefined;
export declare function roleNames(): string[];
/** Resolve one role's persona, route, and effort; undefined for an unknown name. */
export declare function resolveRole(name: string, settings: RoleSettings): RoleResolution | undefined;
/** `provider/model:effort`, or `parent route` when the role inherits. */
export declare function describeRoute(resolution: RoleResolution): string;
//# sourceMappingURL=roles.d.ts.map