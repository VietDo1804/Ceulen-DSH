import type { PluginContext } from '../../core/types.js';
export declare function installOrchestrator(ctx: PluginContext): void;
//# sourceMappingURL=orchestrator.d.ts.map