/**
 * Role-aware delegation for DSH.
 *
 * Ceulen's subagent module ships five role presets (planner, reviewer, scout,
 * tester, worker) plus function-based model routing. DSH already owns child
 * execution, continuation, background notices, and fan-out, so this adapter
 * only adds what the native tools lack: the role persona and the role's
 * provider/model route. `delegate` starts a native spawn child through
 * `ctx.subagents`; `subagent`/`subagent_fork`/`workflow` stay untouched.
 */
import type { PluginContext } from '../../core/types.js';
export declare const name = "ceulen-subagent";
export declare const inject: string[];
export declare function apply(ctx: PluginContext): void;
//# sourceMappingURL=index.d.ts.map