/**
 * Typed delegation: the schema subset `delegate` accepts and the validator the
 * parent runs on the child's final text.
 *
 * The DSH subagent service starts a child and returns its id; it exposes no
 * final-text hook to the plugin. So the contract is enforced in two places we
 * do control: the child prompt (append the schema, "end with exactly one JSON
 * object") and the `validate_schema` tool the parent calls on the reply it
 * received. A malformed reply fails loudly, naming the failing field — never a
 * silent pass.
 */
export interface SchemaNode {
    type?: 'object' | 'array' | 'string' | 'number' | 'integer' | 'boolean';
    required?: string[];
    properties?: Record<string, SchemaNode>;
    items?: SchemaNode;
    enum?: unknown[];
}
/** First schema violation as `path: reason`, or undefined when the value fits. */
export declare function validateValue(schema: SchemaNode, value: unknown, path?: string): string | undefined;
/** Parse and validate a child reply; throws with the failing field named. */
export declare function parseTypedReply(schema: SchemaNode, text: string): unknown;
/** The child-prompt contract appended when `delegate` carries a schema. */
export declare function contractBlock(schema: SchemaNode): string;
//# sourceMappingURL=schema.d.ts.map