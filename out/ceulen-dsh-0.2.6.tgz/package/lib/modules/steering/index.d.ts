import type { AgentLike, PluginContext, UserMessageLike } from '../../core/types.js';
export declare const name = "ceulen-steering";
export declare const inject: string[];
export declare function sessionMovedOn(agent: AgentLike, reviewedSeq: number | undefined): boolean;
/**
 * Park a late note (e.g. a slow advisor review that landed after the user
 * already sent a new prompt) as a harness follow-up: it is delivered after
 * the agent finishes the current task instead of being injected mid-task
 * where the new prompt buries it. Pi `follow_up` semantics; the harness
 * owns the queue, this shelf only remembers what was parked for `/steer`.
 */
export declare function shelveLateNote(agent: AgentLike, message: UserMessageLike, summary: string): boolean;
export declare function apply(ctx: PluginContext): void;
//# sourceMappingURL=index.d.ts.map