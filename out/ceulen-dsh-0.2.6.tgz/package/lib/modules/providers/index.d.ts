import type { PluginContext } from '../../core/types.js';
export declare const name = "ceulen-providers";
export declare const inject: string[];
interface ProvidersConfig {
    target?: 'router' | 'zai';
}
/**
 * Compat fields a thinking-plus-tools loop needs. The DeepSeek API returns a
 * 400 without them, and the 400 reads as a model failure: pin them here so
 * `/ceulen doctor` can name the missing field instead of costing a session.
 */
export declare const TOOL_LOOP_COMPAT_FIELDS: readonly ["supportsToolChoice", "requiresReasoningContentForToolCalls", "requiresAssistantContentForToolCalls"];
export declare const DEEPSEEK_COMPAT: Record<(typeof TOOL_LOOP_COMPAT_FIELDS)[number], boolean>;
export interface ProviderRecipe {
    id: string;
    displayName: string;
    api: string;
    baseURL: string;
    apiKeyEnv: string;
    compat: Record<string, boolean>;
}
/** Pinned recipes: a route names one by provider id. */
export declare const RECIPES: Record<string, ProviderRecipe>;
export interface CompatReport {
    route: string;
    provider: string;
    model?: string;
    /** Declared flags (a boolean is present even when false). */
    present: string[];
    /** Required flags the recipe does not declare. */
    missing: string[];
    /** False when no recipe is pinned for the provider. */
    known: boolean;
}
/**
 * Missing compat fields for one route. `compat` is injectable so a doctor test
 * (or a hand-written profile recipe) can check an incomplete set.
 */
export declare function compatReport(route: string, compat?: Record<string, unknown> | undefined): CompatReport;
/** One doctor line: route, flags present, flags missing (named). */
export declare function formatCompat(report: CompatReport): string;
export declare function apply(ctx: PluginContext, config?: ProvidersConfig): void;
export {};
//# sourceMappingURL=index.d.ts.map