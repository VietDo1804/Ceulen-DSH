/**
 * What models send to the Chrome-backed web tools instead of the declared
 * argument names. Every alias below was counted in the session logs of
 * 1–9 Nov 2026 (403 `web_interact` and 48 `web_screenshot` calls): `width` /
 * `height` 50, `timeout_ms` 46, `reduced_motion` 45, `actions` 12, `full_page`
 * 11, `wait_ms` 8, and step objects written as `{ action, selector }`,
 * `{ type: "wait", ms }` or `{ wait: 900 }`.
 *
 * They used to be dropped without a word, so a "390px" capture ran at the
 * default width and an `actions` list ran no steps at all. The two tools
 * therefore accept undeclared keys, map the known ones here, and name the rest
 * in their result (`ignoredNote`). A declared name always wins over its alias.
 */
type Args = Record<string, unknown>;
/**
 * One step in the shape the browser driver takes: exactly one action key. A
 * step this cannot read is returned unchanged; the driver's own error then
 * lists the valid keys.
 */
export declare function normalizeStep(step: unknown): unknown;
/** `web_interact` arguments with the aliases mapped onto the declared names. */
export declare function normalizeInteractArgs(raw: Args): Args;
/** `web_screenshot` arguments with the aliases mapped onto the declared names. */
export declare function normalizeScreenshotArgs(raw: Args): Args;
/**
 * One result line naming the arguments the tool did not use, or '' when every
 * key is declared. A dropped argument the model never hears about is how a
 * capture at the wrong size gets reported as verified.
 */
export declare function ignoredNote(tool: string, args: unknown, parameters: Record<string, unknown>): string;
export {};
//# sourceMappingURL=args.d.ts.map