import type { PluginContext } from '../../core/types.js';
import type { WebSearchProviderLike } from './types.js';
/** Whether each optional provider registered; web_status reads this. */
export declare const webProviders: {
    brave: boolean;
    fallback: boolean;
};
/** The Brave Search provider: keyed from the credential store, never settings. */
export declare function createBraveProvider(): WebSearchProviderLike;
export declare function registerBrave(ctx: PluginContext): void;
export declare function registerFetchFallback(ctx: PluginContext): void;
//# sourceMappingURL=providers.d.ts.map