export interface ResolvedAddress {
    readonly address: string;
    readonly family: number;
}
/** Injected in tests so DNS behaviour is hermetic. */
export type Resolver = (host: string) => Promise<readonly ResolvedAddress[]>;
/** True when this string is an IP literal inside a blocked range. */
export declare function isBlockedAddress(host: string): boolean;
/** Lexical check: http(s) scheme, no localhost name, no blocked IP literal. */
export declare function isPublicUrl(value: string): boolean;
/**
 * {@link isPublicUrl} plus DNS: a public hostname that resolves to a private
 * address is refused on every redirect hop.
 *
 * ponytail: the check and the connect are separate lookups, so a rebinding host
 * can win the race between them. Connecting to the resolved address would close
 * that window; this is the fallback leg, and the native `http` provider pins
 * connections for the primary path.
 */
export declare function assertPublicUrl(value: string, resolve?: Resolver): Promise<string>;
/**
 * Capture guard for the headless-Chrome tools. A capture can read a page's text
 * through `web_interact`, so the cloud metadata addresses get the same treatment
 * as the fetch guard: IPv4 link-local (169.254.169.254), AWS's IPv6 metadata,
 * multicast, reserved and NAT64 are refused, while loopback and LAN dev servers
 * (including IPv6 link-local) keep working — they are the documented UX-audit
 * flow, and bash can reach them anyway.
 *
 * This checks the first URL only. Redirects, scripts and subresources are held
 * by the Chrome resolver rule in `vendor/ceulen/web/chrome.ts`; keep its list in
 * step with `NEVER_CAPTURE`.
 *
 * ponytail: lexical only, no DNS. A public hostname that resolves to a private
 * address still passes here; closing that needs the async resolver and an async
 * capture guard.
 */
export declare function captureUrlProblem(value: string): string | undefined;
//# sourceMappingURL=url-guard.d.ts.map