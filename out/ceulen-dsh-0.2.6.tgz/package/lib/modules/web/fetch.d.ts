import type { PluginContext } from '../../core/types.js';
import type { WebFetchProviderLike, WebFetchResult } from './types.js';
export declare function fetchPage(ctx: PluginContext, url: string, signal: AbortSignal, options?: {
    direct?: boolean;
}): Promise<WebFetchResult>;
export declare const FALLBACK_FETCH_PROVIDER_ID = "deepseek-fetch-fallback";
/** Page Markdown from the DeepSeek Fetch API; throws on any non-usable reply. */
export declare function fetchDeepSeekMarkdown(url: string, key: string, signal?: AbortSignal): Promise<WebFetchResult>;
/**
 * Local HTTP fetch for the fallback leg and the service-less path. Redirects
 * are followed by hand so every hop is re-checked against {@link assertPublicUrl}
 * (the native `http` provider pins connections; this is the cheap equivalent).
 */
export declare function fetchDirectPublic(url: string, signal?: AbortSignal): Promise<WebFetchResult>;
/**
 * DeepSeek Fetch API (clean page Markdown) with a local HTTP fallback,
 * registered as a native fetch provider so `web_fetch`, `web_extract`, and
 * `web_map` all degrade to the local fetcher when the API fails — 401/429, a
 * timeout, or a page its extractor cannot handle (e.g. reddit returns 404).
 */
export declare function createFallbackFetchProvider(): WebFetchProviderLike;
/**
 * web_map needs raw HTML, but a markdown fetch pin (`deepseek-fetch-api`)
 * returns `kind: 'text'` from the service. Only then re-fetch directly, so the
 * native validation/redirect policy still governs the normal `http` pin.
 */
export declare function fetchHtmlPage(ctx: PluginContext, url: string, signal: AbortSignal): Promise<WebFetchResult>;
/**
 * Capture tools (screenshot, PDF, interact, runtime UX audit) take http(s) URLs
 * and any file:// inside the workspace. `assertCaptureUrl` is only the
 * argv-injection guard (the URL becomes a spawn argument); `captureUrlProblem`
 * adds the network boundary for link-local/metadata ranges, while loopback and
 * LAN dev servers stay auditable.
 */
//# sourceMappingURL=fetch.d.ts.map