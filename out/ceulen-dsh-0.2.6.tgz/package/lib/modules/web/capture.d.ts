import type { PluginContext } from '../../core/types.js';
export declare function assertCaptureScope(url: string, cwd: string): void;
export declare function saveScreenshot(ctx: PluginContext, base64: string, name: string, attach?: boolean): Promise<{
    text: string;
    image?: unknown;
}>;
export declare function savePdfFile(pdfBase64: string, name: string): Promise<string>;
export declare const IMAGE_RESULT_SCHEMA: {
    type: string;
    properties: {
        text: {
            type: string;
        };
        image: {
            type: string;
            additionalProperties: boolean;
        };
    };
    required: string[];
};
export declare const imageRender: (_args: unknown, value: unknown) => never;
//# sourceMappingURL=capture.d.ts.map