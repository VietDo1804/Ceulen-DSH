import type { PluginContext } from '../../core/types.js';
/** The seven model-facing web tools; the command surface stays in index.ts. */
export declare function registerWebTools(ctx: PluginContext): void;
//# sourceMappingURL=tools.d.ts.map