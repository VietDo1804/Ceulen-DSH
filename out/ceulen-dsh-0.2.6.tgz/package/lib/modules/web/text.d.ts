export declare function decodeEntities(text: string): string;
export declare function htmlToText(html: string): {
    title: string;
    text: string;
    links: string[];
};
//# sourceMappingURL=text.d.ts.map