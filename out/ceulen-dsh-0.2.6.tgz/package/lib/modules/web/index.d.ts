/**
 * Ceulen web module: providers, the model-facing web tools and the status
 * command. The split keeps the seams readable:
 *
 * - types.ts     service shapes and provider interfaces
 * - text.ts      HTML → text
 * - fetch.ts     fetch page (DeepSeek Markdown) + local public-URL fetch leg
 * - capture.ts   headless-Chrome capture scope, screenshot/PDF persistence
 * - providers.ts Brave search + fetch-fallback registration
 * - tools.ts     web_extract/map/screenshot/pdf/interact/chat/status
 * - url-guard.ts the public-URL and capture-target guard
 */
import type { PluginContext } from '../../core/types.js';
export declare const name = "ceulen-web";
export declare const inject: string[];
export { htmlToText } from './text.js';
export { createBraveProvider } from './providers.js';
export { createFallbackFetchProvider, FALLBACK_FETCH_PROVIDER_ID } from './fetch.js';
export { assertCaptureScope } from './capture.js';
export declare function apply(ctx: PluginContext): void;
//# sourceMappingURL=index.d.ts.map