/**
 * `/ceulen-config` — the central settings panel for every Ceulen module.
 *
 * The bare `/config` name is registered too, but the TUI owns a local command
 * by that name (it prints the dsh-tui configuration source) and local commands
 * win collisions, so `/ceulen-config` is the spelling to document for the TUI.
 *
 * The command opens a full-screen TUI scene (registered through `tuiScenes`)
 * and falls back to a text dump in headless or non-TUI compositions. Values
 * are written to `$DSH_HOME/ceulen/settings.json` on save; modules that read
 * the file per call pick them up immediately, timers and prompt sections need
 * `/reload`.
 */
import type { PluginContext } from '../../core/types.js';
import { type ConfigProvider } from './model.js';
/** Use adapter authentication metadata, never provider-name guesses or secrets. */
export declare function collectConfigProviders(ctx: PluginContext): ConfigProvider[];
/**
 * `provider/model` for every model the registered providers advertise, in
 * registry order. One provider failing discovery must not hide the rest, so
 * each lookup settles independently.
 */
export declare function collectModelRoutes(ctx: PluginContext): Promise<string[]>;
export interface ConfigPanelApi {
    /** Open the scene when a TUI is mounted; false means "use text()". */
    open(): boolean;
    text(filter?: string): {
        kind: 'success' | 'error';
        text: string;
    };
    help(command?: string): string;
}
/**
 * Register the config panel (scene + commands) and return the handles the
 * status row uses for `/ceulen config`.
 *
 * DSH owns a local `/config` command ("show the dsh-tui configuration
 * source") and local commands win name collisions, so the scene is reachable
 * as `/ceulen-config` in the TUI. The bare `/config` registration still works
 * in compositions that do not ship that local command (headless, web).
 */
export declare function applyConfig(ctx: PluginContext): ConfigPanelApi;
//# sourceMappingURL=index.d.ts.map