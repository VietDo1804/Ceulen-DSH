import type { CeulenSettings } from '../../core/settings.js';
import type { ConfigContext, ConfigTab } from './types.js';
/** Shell, Tasks, Providers, Tools and Plugins tabs. */
export declare function buildExtraTabs(settings: CeulenSettings, context: ConfigContext, routes: readonly string[], a2aPeers: number): ConfigTab[];
//# sourceMappingURL=tabs-extra.d.ts.map