/**
 * Full-screen `/config` scene.
 *
 * Registered through the TUI's `tuiScenes` seam. The host injects its own
 * React and ui kit, so this file imports no React and no dsh-tui package —
 * a headless composition never loads it.
 */
import { type ConfigContext } from './model.js';
interface KeyFlags {
    upArrow: boolean;
    downArrow: boolean;
    leftArrow: boolean;
    rightArrow: boolean;
    pageUp: boolean;
    pageDown: boolean;
    wheelUp: boolean;
    wheelDown: boolean;
    home: boolean;
    end: boolean;
    return: boolean;
    escape: boolean;
    ctrl: boolean;
    shift: boolean;
    tab: boolean;
    backspace: boolean;
    delete: boolean;
    meta: boolean;
}
interface SceneReact {
    useState<T>(initial: T | (() => T)): [T, (value: T | ((previous: T) => T)) => void];
    useEffect(effect: () => void | (() => void), deps?: readonly unknown[]): void;
    createElement(type: unknown, props?: Record<string, unknown> | null, ...children: unknown[]): unknown;
}
interface SceneUi {
    Box: unknown;
    Text: unknown;
    useInput(handler: (input: string, key: KeyFlags) => void, options?: {
        isActive?: boolean;
    }): void;
    useTerminalSize(): {
        columns: number;
        rows: number;
    };
}
export interface SceneProps {
    React: SceneReact;
    ui: SceneUi;
    close(): void;
}
export interface ConfigSceneOptions {
    /** Rebuilt on every open so env/routes reflect the live process. */
    context: () => ConfigContext;
    onSaved?: () => void;
    /** DSH credential store writes for `secret` rows; absent means read-only. */
    secret?: {
        write(ref: string, value: string): Promise<void>;
    };
}
export declare function createConfigScene(options: ConfigSceneOptions): (props: SceneProps) => unknown;
export {};
//# sourceMappingURL=scene.d.ts.map