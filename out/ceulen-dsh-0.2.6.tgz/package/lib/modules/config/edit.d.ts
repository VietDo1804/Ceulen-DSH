import type { ConfigRow, ConfigTab, ConfigValue } from './types.js';
export declare function displayValue(row: ConfigRow): string;
/**
 * Turn inline-editor text into a typed value. `undefined` means the draft is
 * not a value this row accepts (the editor stays open and says why).
 */
export declare function parseEditValue(row: ConfigRow, text: string): ConfigValue | undefined;
/** Plain-text rendering used headlessly and by `/config show`. */
export declare function summaryLines(tabs: readonly ConfigTab[], settingsFile: string): string;
//# sourceMappingURL=edit.d.ts.map