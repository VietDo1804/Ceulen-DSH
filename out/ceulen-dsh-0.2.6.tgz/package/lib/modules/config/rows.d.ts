import type { ConfigContext, ConfigKind, ConfigRow, ConfigValue, RowOptions } from './types.js';
export declare function row(key: string, label: string, kind: ConfigKind, value: ConfigValue, set: ((value: ConfigValue) => void) | undefined, options?: RowOptions): ConfigRow;
export declare function text(key: string, label: string, value: string, set: (value: string) => void, options?: RowOptions): ConfigRow;
export declare function toggle(key: string, label: string, value: boolean, set: (value: boolean) => void, options?: RowOptions): ConfigRow;
export declare function number(key: string, label: string, value: number, set: (value: number) => void, min: number, max: number, options?: RowOptions): ConfigRow;
export declare function option(key: string, label: string, value: string, values: readonly string[], set: (value: string) => void, options?: RowOptions): ConfigRow;
export declare function info(key: string, label: string, value: string, description?: string): ConfigRow;
/**
 * A credential row: shows presence only and edits go to the DSH credential
 * store, so no secret ever lands in settings.json or the transcript.
 */
export declare function secret(context: ConfigContext, key: string, label: string, ref: string, description?: string): ConfigRow;
/** Presence label for a credential ref; never the value. */
export declare function secretStatus(ref: string): string;
//# sourceMappingURL=rows.d.ts.map