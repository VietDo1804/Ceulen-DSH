import { type CeulenSettings, type ReasoningEffort } from '../../core/settings.js';
import type { ConfigContext } from './types.js';
export declare function clampNumber(value: number, min: number, max: number): number;
export declare function envValue(context: ConfigContext, name: string): string;
export declare function routeText(provider: string | null, model: string | null, effort?: ReasoningEffort | null): string;
export declare function planTargets(settings: CeulenSettings): string;
/** Parse `provider/model[:effort]`; empty clears the route. */
export declare function splitRoute(value: string): {
    provider: string;
    model: string;
    effort: ReasoningEffort | null;
} | null;
export declare function splitList(value: string): string[];
/** Case-insensitive substring filter used by the model picker. */
export declare function filterRoutes(routes: readonly string[], filter: string): string[];
/**
 * Route the picker commits: the highlighted catalog entry, else a typed
 * `provider/model` — catalog membership is advisory, so unlisted model ids
 * stay reachable. `-` commits an empty value (clear), and `*` / `@alias` are
 * role selectors the row's own setter validates.
 */
export declare function pickerRoute(visible: readonly string[], cursor: number, filter: string): string | undefined;
/**
 * Keep the row's existing `:effort` suffix when the picked route has none.
 * A pick that is not a route (`@alias`, `*`, `''`) is returned untouched.
 */
export declare function keepEffort(picked: string, current: string): string;
/**
 * Append one picked route to a comma-separated list, keeping order and dedupe.
 * A pick without `:effort` never duplicates the same model that is already
 * listed with one — the existing entry (and its effort) wins; a pick that has
 * an effort replaces that entry instead of adding a second copy.
 */
export declare function appendRouteList(current: string, picked: string): string;
export declare function routeList(value: string): string[];
/**
 * Selector stored in `subagent.models.<role>`: `provider/model[:effort]`,
 * `@alias`, `*`, or empty to clear. Malformed routes throw so the editor stays
 * open instead of writing an entry the resolver silently drops.
 */
export declare function roleSelector(value: string): string;
//# sourceMappingURL=helpers.d.ts.map