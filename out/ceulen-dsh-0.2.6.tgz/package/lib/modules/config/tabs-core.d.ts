import { type CeulenSettings } from '../../core/settings.js';
import type { ConfigContext, ConfigRow, ConfigTab } from './types.js';
/** The per-role model/reasoning rows, reused by the Model tab. */
export declare function buildSubagentRows(settings: CeulenSettings): ConfigRow[];
/** Appearance, Model, Memory and Context tabs. */
export declare function buildCoreTabs(settings: CeulenSettings, context: ConfigContext, subagentRows: ConfigRow[]): ConfigTab[];
//# sourceMappingURL=tabs-core.d.ts.map