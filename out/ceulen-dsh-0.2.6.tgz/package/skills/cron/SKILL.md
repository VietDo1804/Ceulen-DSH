---
name: cron
description: Use when the user wants scheduled, recurring, or periodic tasks in Pi — cron jobs, reminders, jobs at a specific time ("every morning at 9", "weekly monday", "in 30 minutes"), or automation that should run without being asked each time.
---

# cron — scheduled jobs

Jobs fire a prompt **into the live session** while pi is running. Past-due jobs
catch up once on the next tick (~30s). Storage: `<agentDir>/cron/jobs.json`.

## Creating jobs

1. Convert the user's natural language to a **5-field cron expression**.
2. Verify it with `cron action:"test" schedule:"..."` — check the next 5 fire times.
3. Add it: `cron action:"add" name:"<short-name>" schedule:"..." prompt:"..."`.

Cheatsheet: `minute hour day-of-month month day-of-week`

- `0 9 * * mon` — Mondays 09:00
- `*/30 * * * *` — every 30 minutes
- `0 9 1 * *` — first of the month, 09:00
- `30 8 * * 1-5` — weekdays 08:30

Names: letters/digits/`_`/`.`/`-`, max 64 chars. Cap: 20 jobs.

## Job prompts

The prompt becomes a **standalone turn** — no conversation context. Write it
self-contained and short: what to do, where, and what to report. Bad: `"check
it again"`; good: `"Run npm test in this repo and summarize failures"`.

**Loop guard:** for 30s after a fire, `add`, `remove`, `run`, `enable`, and
`disable` are refused. A fired turn running longer than 30s can still mutate —
never write job prompts that schedule further jobs.

**Working directory:** unpinned jobs deliver only into a session whose cwd
matches the job's `cwd`; a foreign-cwd session marks the fire
`[FAIL: cwd mismatch …]`. Pin `model`/`thinking` for cross-cwd reliability
(pinned jobs run headless in `job.cwd`).

## Managing

- `cron action:"list"` — name, schedule, next/last fire, enabled.
- `cron action:"run" name:"..."` — manual fire (result arrives as a follow-up turn).
- `cron action:"disable" name:"..."` — pause a job (schedule kept; skipped by ticks and export).
- `cron action:"enable" name:"..."` — resume; the next fire is recomputed from now (no surprise catch-up fire).
- `cron action:"add" ... enabled:false` — create the job already disabled.
- `cron action:"remove" name:"..."`.
- `cron action:"export"` — crontab lines for 24/7 coverage while pi is closed;
  hand the block to the user to install (`crontab -l | cat - cron.txt | crontab -`).
  Exported lines run headless `pi -p --no-session` and log under `<agentDir>/cron/logs/`.

## Config

`settings.json` → `"cron": { "enabled": true, "tickMs": 30000 }` (global kill
switch + tick interval). `timeoutMs` caps headless (pinned) child runs
(SIGTERM at the cap, SIGKILL after a 5s grace; clamped 1min–24h, default
10min) — raise it for long pinned jobs.
